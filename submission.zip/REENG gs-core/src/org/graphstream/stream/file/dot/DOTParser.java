//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package org.graphstream.stream.file.dot;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.graphstream.graph.IdAlreadyInUseException;
import org.graphstream.graph.implementations.AbstractElement.AttributeChangeEvent;
import org.graphstream.stream.SourceBase.ElementType;
import org.graphstream.stream.file.FileSourceDOT;
import org.graphstream.stream.file.ParserBase;
import org.graphstream.util.parser.ParseException;
import org.graphstream.util.parser.Parser;
import org.graphstream.util.parser.SimpleCharStream;
import org.graphstream.util.parser.Token;

public class DOTParser extends ParserBase implements Parser, DOTParserConstants {
    private FileSourceDOT dot;
    private String sourceId;
    private boolean directed;
    private boolean strict;
    private HashMap<String, Object> globalNodesAttributes;
    private HashMap<String, Object> globalEdgesAttributes;
    private HashSet<String> nodeAdded;
    public DOTParserTokenManager token_source;
    SimpleCharStream jj_input_stream;
    public Token jj_nt;
    private int jj_ntk;
    private int jj_gen;
    private final int[] jj_la1;
    private static int[] jj_la1_0;
    private static int[] jj_la1_1;
    private final DOTParser.JJCalls[] jj_2_rtns;
    private int jj_gc;
    private int jj_kind;
    private Token jj_scanpos;
    private Token jj_lastpos;
    private int jj_la;
    private boolean jj_rescan;
    private static ParserBase.LookaheadSuccess jj_ls;
    private int[] jj_lasttokens;
    private List<int[]> jj_expentries;
    private int[] jj_expentry;
    private int jj_endpos;


    public DOTParser(FileSourceDOT dot, InputStream stream) {
        this(stream);
        this.init(dot);
    }

    public DOTParser(FileSourceDOT dot, Reader stream) {
        this(stream);
        this.init(dot);
    }

    public void close() throws IOException {
        this.jj_input_stream.close();
    }

    private void init(FileSourceDOT dot) {
        this.dot = dot;
        this.sourceId = String.format("<DOT stream %x>", System.nanoTime());
        this.globalNodesAttributes = new HashMap();
        this.globalEdgesAttributes = new HashMap();
        this.nodeAdded = new HashSet();
    }

    private void addNode(String nodeId, String[] port, HashMap<String, Object> attr) {
        Iterator var4;
        String key;
        if (this.nodeAdded.contains(nodeId)) {
            if (attr != null) {
                var4 = attr.keySet().iterator();

                while(var4.hasNext()) {
                    key = (String)var4.next();
                    this.dot.sendAttributeChangedEvent(this.sourceId, nodeId, ElementType.NODE, key, AttributeChangeEvent.ADD, (Object)null, attr.get(key));
                }
            }
        } else {
            this.dot.sendNodeAdded(this.sourceId, nodeId);
            this.nodeAdded.add(nodeId);
            if (attr == null) {
                var4 = this.globalNodesAttributes.keySet().iterator();

                while(var4.hasNext()) {
                    key = (String)var4.next();
                    this.dot.sendAttributeChangedEvent(this.sourceId, nodeId, ElementType.NODE, key, AttributeChangeEvent.ADD, (Object)null, this.globalNodesAttributes.get(key));
                }
            } else {
                var4 = this.globalNodesAttributes.keySet().iterator();

                while(var4.hasNext()) {
                    key = (String)var4.next();
                    if (!attr.containsKey(key)) {
                        this.dot.sendAttributeChangedEvent(this.sourceId, nodeId, ElementType.NODE, key, AttributeChangeEvent.ADD, (Object)null, this.globalNodesAttributes.get(key));
                    }
                }

                var4 = attr.keySet().iterator();

                while(var4.hasNext()) {
                    key = (String)var4.next();
                    this.dot.sendAttributeChangedEvent(this.sourceId, nodeId, ElementType.NODE, key, AttributeChangeEvent.ADD, (Object)null, attr.get(key));
                }
            }
        }

    }

    private void addEdges(LinkedList<String> edges, HashMap<String, Object> attr) {
        HashMap<String, Integer> hash = new HashMap();
        String[] ids = new String[(edges.size() - 1) / 2];
        boolean[] directed = new boolean[(edges.size() - 1) / 2];
        int count = 0;

        int i;
        String IDtoTry;
        String key;
        for(i = 0; i < edges.size() - 1; i += 2) {
            String from = (String)edges.get(i);
            IDtoTry = (String)edges.get(i + 2);
            if (!this.nodeAdded.contains(from)) {
                this.addNode(from, (String[])null, (HashMap)null);
            }

            if (!this.nodeAdded.contains(IDtoTry)) {
                this.addNode(IDtoTry, (String[])null, (HashMap)null);
            }

            String edgeId = String.format("(%s;%s)", from, IDtoTry);
            key = String.format("(%s;%s)", IDtoTry, from);
            if (hash.containsKey(key)) {
                directed[(Integer)hash.get(key)] = false;
            } else {
                hash.put(edgeId, count);
                ids[count] = edgeId;
                directed[count] = ((String)edges.get(i + 1)).equals("->");
                ++count;
            }
        }

        hash.clear();
        if (count == 1 && attr != null && attr.containsKey("id")) {
            ids[0] = attr.get("id").toString();
            attr.remove("id");
        }

        for(i = 0; i < count; ++i) {
            boolean addedEdge = false;
            IDtoTry = ids[i];

            while(!addedEdge) {
                try {
                    this.dot.sendEdgeAdded(this.sourceId, ids[i], (String)edges.get(i * 2), (String)edges.get((i + 1) * 2), directed[i]);
                    addedEdge = true;
                } catch (IdAlreadyInUseException var12) {
                    IDtoTry = IDtoTry + "'";
                }
            }

            Iterator var14;
            if (attr == null) {
                var14 = this.globalEdgesAttributes.keySet().iterator();

                while(var14.hasNext()) {
                    key = (String)var14.next();
                    this.dot.sendAttributeChangedEvent(this.sourceId, ids[i], ElementType.EDGE, key, AttributeChangeEvent.ADD, (Object)null, this.globalEdgesAttributes.get(key));
                }
            } else {
                var14 = this.globalEdgesAttributes.keySet().iterator();

                while(var14.hasNext()) {
                    key = (String)var14.next();
                    if (!attr.containsKey(key)) {
                        this.dot.sendAttributeChangedEvent(this.sourceId, ids[i], ElementType.EDGE, key, AttributeChangeEvent.ADD, (Object)null, this.globalEdgesAttributes.get(key));
                    }
                }

                var14 = attr.keySet().iterator();

                while(var14.hasNext()) {
                    key = (String)var14.next();
                    this.dot.sendAttributeChangedEvent(this.sourceId, ids[i], ElementType.EDGE, key, AttributeChangeEvent.ADD, (Object)null, attr.get(key));
                }
            }
        }

    }

    private void setGlobalAttributes(String who, HashMap<String, Object> attr) {
        if (who.equalsIgnoreCase("graph")) {
            Iterator var3 = attr.keySet().iterator();

            while(var3.hasNext()) {
                String key = (String)var3.next();
                this.dot.sendAttributeChangedEvent(this.sourceId, this.sourceId, ElementType.GRAPH, key, AttributeChangeEvent.ADD, (Object)null, attr.get(key));
            }
        } else if (who.equalsIgnoreCase("node")) {
            this.globalNodesAttributes.putAll(attr);
        } else if (who.equalsIgnoreCase("edge")) {
            this.globalEdgesAttributes.putAll(attr);
        }

    }

    public final void all() throws ParseException {
        this.graph();

        while(true) {
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                case 17:
                case 19:
                case 20:
                case 21:
                case 24:
                case 25:
                case 26:
                    this.statement();
                    break;
                case 18:
                case 22:
                case 23:
                default:
                    this.jj_la1[0] = this.jj_gen;
                    this.jj_consume_token(13);
                    return;
            }
        }
    }

    public final boolean next() throws ParseException {
        boolean hasMore = false;
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 0:
                this.jj_consume_token(0);
                break;
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 14:
            case 15:
            case 16:
            case 18:
            case 22:
            case 23:
            default:
                this.jj_la1[1] = this.jj_gen;
                this.jj_consume_token(-1);
                throw new ParseException();
            case 13:
                this.jj_consume_token(13);
                break;
            case 17:
            case 19:
            case 20:
            case 21:
            case 24:
            case 25:
            case 26:
                this.statement();
                hasMore = true;
        }

        return hasMore;
    }

    public final void open() throws ParseException {
        this.graph();
    }

    private final void graph() throws ParseException {
        this.directed = false;
        this.strict = false;
        this.globalNodesAttributes.clear();
        this.globalEdgesAttributes.clear();
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 22:
                this.jj_consume_token(22);
                this.strict = true;
                break;
            default:
                this.jj_la1[2] = this.jj_gen;
        }

        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 17:
                this.jj_consume_token(17);
                break;
            case 18:
                this.jj_consume_token(18);
                this.directed = true;
                break;
            default:
                this.jj_la1[3] = this.jj_gen;
                this.jj_consume_token(-1);
                throw new ParseException();
        }

        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 24:
            case 25:
            case 26:
                this.sourceId = this.id();
                break;
            default:
                this.jj_la1[4] = this.jj_gen;
        }

        this.jj_consume_token(12);
    }

    private final void subgraph() throws ParseException {
        this.jj_consume_token(19);
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 24:
            case 25:
            case 26:
                this.id();
                break;
            default:
                this.jj_la1[5] = this.jj_gen;
        }

        this.jj_consume_token(12);

        while(true) {
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                case 17:
                case 19:
                case 20:
                case 21:
                case 24:
                case 25:
                case 26:
                    this.statement();
                    break;
                case 18:
                case 22:
                case 23:
                default:
                    this.jj_la1[6] = this.jj_gen;
                    this.jj_consume_token(13);
                    return;
            }
        }
    }

    private final String id() throws ParseException {
        Token t;
        String id;
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 24:
                t = this.jj_consume_token(24);
                id = t.image;
                break;
            case 25:
                t = this.jj_consume_token(25);
                id = t.image.substring(1, t.image.length() - 1);
                break;
            case 26:
                t = this.jj_consume_token(26);
                id = t.image;
                break;
            default:
                this.jj_la1[7] = this.jj_gen;
                this.jj_consume_token(-1);
                throw new ParseException();
        }

        return id;
    }

    private final void statement() throws ParseException {
        if (this.jj_2_1(3)) {
            this.edgeStatement();
        } else {
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                case 17:
                case 20:
                case 21:
                    this.attributeStatement();
                    break;
                case 18:
                case 22:
                case 23:
                default:
                    this.jj_la1[8] = this.jj_gen;
                    this.jj_consume_token(-1);
                    throw new ParseException();
                case 19:
                    this.subgraph();
                    break;
                case 24:
                case 25:
                case 26:
                    this.nodeStatement();
            }
        }

        this.jj_consume_token(27);
    }

    private final void nodeStatement() throws ParseException {
        HashMap<String, Object> attr = null;
        String[] port = null;
        String nodeId = this.id();
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 14:
                port = this.port();
                break;
            default:
                this.jj_la1[9] = this.jj_gen;
        }

        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 10:
                attr = this.attributesList();
                break;
            default:
                this.jj_la1[10] = this.jj_gen;
        }

        this.addNode(nodeId, port, attr);
    }

    private final String compassPoint() throws ParseException {
        Token pt = null;
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 28:
                pt = this.jj_consume_token(28);
                break;
            case 29:
                pt = this.jj_consume_token(29);
                break;
            case 30:
                pt = this.jj_consume_token(30);
                break;
            case 31:
                pt = this.jj_consume_token(31);
                break;
            case 32:
                pt = this.jj_consume_token(32);
                break;
            case 33:
                pt = this.jj_consume_token(33);
                break;
            case 34:
                pt = this.jj_consume_token(34);
                break;
            case 35:
                pt = this.jj_consume_token(35);
                break;
            case 36:
                pt = this.jj_consume_token(36);
                break;
            case 37:
                pt = this.jj_consume_token(37);
                break;
            default:
                this.jj_la1[11] = this.jj_gen;
                this.jj_consume_token(-1);
                throw new ParseException();
        }

        return pt.image;
    }

    private final String[] port() throws ParseException {
        String[] p = new String[]{null, null};
        this.jj_consume_token(14);
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 24:
            case 25:
            case 26:
                p[0] = this.id();
                switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                    case 14:
                        this.jj_consume_token(14);
                        p[1] = this.compassPoint();
                        return p;
                    default:
                        this.jj_la1[12] = this.jj_gen;
                        return p;
                }
            case 27:
            default:
                this.jj_la1[13] = this.jj_gen;
                this.jj_consume_token(-1);
                throw new ParseException();
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
                p[1] = this.compassPoint();
                return p;
        }
    }

    private final void edgeStatement() throws ParseException {
        LinkedList<String> edges = new LinkedList();
        HashMap<String, Object> attr = null;
        String id = this.id();
        edges.add(id);
        this.edgeRHS(edges);
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 10:
                attr = this.attributesList();
                break;
            default:
                this.jj_la1[14] = this.jj_gen;
        }

        this.addEdges(edges, attr);
    }

    private final void edgeRHS(LinkedList<String> edges) throws ParseException {
        Token t = this.jj_consume_token(23);
        edges.add(t.image);
        String i = this.id();
        edges.add(i);
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 23:
                this.edgeRHS(edges);
                break;
            default:
                this.jj_la1[15] = this.jj_gen;
        }

    }

    private final void attributeStatement() throws ParseException {
        Token t;
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 17:
                t = this.jj_consume_token(17);
                break;
            case 18:
            case 19:
            default:
                this.jj_la1[16] = this.jj_gen;
                this.jj_consume_token(-1);
                throw new ParseException();
            case 20:
                t = this.jj_consume_token(20);
                break;
            case 21:
                t = this.jj_consume_token(21);
        }

        HashMap<String, Object> attr = this.attributesList();
        this.setGlobalAttributes(t.image, attr);
    }

    private final HashMap<String, Object> attributesList() throws ParseException {
        HashMap attributes = new HashMap();

        while(true) {
            this.jj_consume_token(10);
            label36:
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                case 24:
                case 25:
                case 26:
                    this.attributeList(attributes);

                    while(true) {
                        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                            case 15:
                                this.jj_consume_token(15);
                                this.attributeList(attributes);
                                break;
                            default:
                                this.jj_la1[17] = this.jj_gen;
                                break label36;
                        }
                    }
                default:
                    this.jj_la1[18] = this.jj_gen;
            }

            this.jj_consume_token(11);
            switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                case 10:
                    break;
                default:
                    this.jj_la1[19] = this.jj_gen;
                    return attributes;
            }
        }
    }

    private final void attributeList(HashMap<String, Object> attributes) throws ParseException {
        String key;
        Object val;
        key = this.id();
        val = Boolean.TRUE;
        label22:
        switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
            case 16:
                this.jj_consume_token(16);
                if (this.jj_2_2(2)) {
                    Token t = this.jj_consume_token(24);
                    val = Double.parseDouble(t.image);
                    break;
                } else {
                    switch(this.jj_ntk == -1 ? this.jj_ntk() : this.jj_ntk) {
                        case 24:
                        case 25:
                        case 26:
                            val = this.id();
                            break label22;
                        default:
                            this.jj_la1[20] = this.jj_gen;
                            this.jj_consume_token(-1);
                            throw new ParseException();
                    }
                }
            default:
                this.jj_la1[21] = this.jj_gen;
        }

        attributes.put(key, val);
    }

    private boolean jj_2_1(int xla) {
        this.jj_la = xla;
        this.jj_lastpos = this.jj_scanpos = this.token;

        boolean var3;
        try {
            boolean var2 = !this.jj_3_1();
            return var2;
        } catch (DOTParser.LookaheadSuccess var7) {
            var3 = true;
        } finally {
            this.jj_save(0, xla);
        }

        return var3;
    }

    private boolean jj_2_2(int xla) {
        this.jj_la = xla;
        this.jj_lastpos = this.jj_scanpos = this.token;

        boolean var3;
        try {
            boolean var2 = !this.jj_3_2();
            return var2;
        } catch (DOTParser.LookaheadSuccess var7) {
            var3 = true;
        } finally {
            this.jj_save(1, xla);
        }

        return var3;
    }

    private boolean jj_3R_6() {
        Token xsp = this.jj_scanpos;
        if (this.jj_3R_8()) {
            this.jj_scanpos = xsp;
            if (this.jj_3R_9()) {
                this.jj_scanpos = xsp;
                if (this.jj_3R_10()) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean jj_3_2() {
        return this.jj_scan_token(24);
    }

    private boolean jj_3R_8() {
        return this.jj_scan_token(25);
    }

    private boolean jj_3R_10() {
        return this.jj_scan_token(26);
    }

    private boolean jj_3R_7() {
        if (this.jj_scan_token(23)) {
            return true;
        } else {
            return this.jj_3R_6();
        }
    }

    private boolean jj_3R_9() {
        return this.jj_scan_token(24);
    }

    private boolean jj_3R_5() {
        if (this.jj_3R_6()) {
            return true;
        } else {
            return this.jj_3R_7();
        }
    }

    private boolean jj_3_1() {
        return this.jj_3R_5();
    }

    private static void jj_la1_init_0() {
        jj_la1_0 = new int[]{121241600, 121249793, 4194304, 393216, 117440512, 117440512, 121241600, 117440512, 121241600, 16384, 1024, -268435456, 16384, -150994944, 1024, 8388608, 3276800, 32768, 117440512, 1024, 117440512, 65536};
    }

    private static void jj_la1_init_1() {
        jj_la1_1 = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63, 0, 63, 0, 0, 0, 0, 0, 0, 0, 0};
    }

    public DOTParser(InputStream stream) {
        this((InputStream)stream, (String)null);
    }

    public DOTParser(InputStream stream, String encoding) {
        super(jj_ls);
        //jj_ls= new ParserBase();
        this.jj_la1 = new int[22];
        this.jj_2_rtns = new DOTParser.JJCalls[2];
        this.jj_rescan = false;
        this.jj_gc = 0;
        this.jj_ls = new ParserBase.LookaheadSuccess();
        this.jj_expentries = new ArrayList();
        this.jj_kind = -1;
        this.jj_lasttokens = new int[100];

        try {
            this.jj_input_stream = new SimpleCharStream(stream, encoding, 1, 1);
        } catch (UnsupportedEncodingException var4) {
            throw new RuntimeException(var4);
        }

        this.token_source = new DOTParserTokenManager(this.jj_input_stream);
        this.token = new Token();
        this.jj_ntk = -1;
        this.jj_gen = 0;

        int i;
        for(i = 0; i < 22; ++i) {
            this.jj_la1[i] = -1;
        }

        for(i = 0; i < this.jj_2_rtns.length; ++i) {
            this.jj_2_rtns[i] = new DOTParser.JJCalls();
        }

    }

    public void ReInit(InputStream stream) {
        this.ReInit(stream, (String)null);
    }

    public void ReInit(InputStream stream, String encoding) {
        try {
            this.jj_input_stream.ReInit(stream, encoding, 1, 1);
        } catch (UnsupportedEncodingException var4) {
            throw new RuntimeException(var4);
        }

        this.token_source.ReInit(this.jj_input_stream);
        this.token = new Token();
        this.jj_ntk = -1;
        this.jj_gen = 0;

        int i;
        for(i = 0; i < 22; ++i) {
            this.jj_la1[i] = -1;
        }

        for(i = 0; i < this.jj_2_rtns.length; ++i) {
            this.jj_2_rtns[i] = new DOTParser.JJCalls();
        }

    }

    public DOTParser(Reader stream) {
        super(jj_ls);
        this.jj_la1 = new int[22];
        this.jj_2_rtns = new DOTParser.JJCalls[2];
        this.jj_rescan = false;
        this.jj_gc = 0;
        this.jj_ls = new ParserBase.LookaheadSuccess();
        this.jj_expentries = new ArrayList();
        this.jj_kind = -1;
        this.jj_lasttokens = new int[100];
        this.jj_input_stream = new SimpleCharStream(stream, 1, 1);
        this.token_source = new DOTParserTokenManager(this.jj_input_stream);
        this.token = new Token();
        this.jj_ntk = -1;
        this.jj_gen = 0;

        int i;
        for(i = 0; i < 22; ++i) {
            this.jj_la1[i] = -1;
        }

        for(i = 0; i < this.jj_2_rtns.length; ++i) {
            this.jj_2_rtns[i] = new DOTParser.JJCalls();
        }

    }

    public void ReInit(Reader stream) {
        this.jj_input_stream.ReInit(stream, 1, 1);
        this.token_source.ReInit(this.jj_input_stream);
        this.token = new Token();
        this.jj_ntk = -1;
        this.jj_gen = 0;

        int i;
        for(i = 0; i < 22; ++i) {
            this.jj_la1[i] = -1;
        }

        for(i = 0; i < this.jj_2_rtns.length; ++i) {
            this.jj_2_rtns[i] = new DOTParser.JJCalls();
        }

    }

    public DOTParser(DOTParserTokenManager tm) {
        super(jj_ls);
        this.jj_la1 = new int[22];
        this.jj_2_rtns = new DOTParser.JJCalls[2];
        this.jj_rescan = false;
        this.jj_gc = 0;
        this.jj_ls = new ParserBase.LookaheadSuccess();
        this.jj_expentries = new ArrayList();
        this.jj_kind = -1;
        this.jj_lasttokens = new int[100];
        this.token_source = tm;
        this.token = new Token();
        this.jj_ntk = -1;
        this.jj_gen = 0;

        int i;
        for(i = 0; i < 22; ++i) {
            this.jj_la1[i] = -1;
        }

        for(i = 0; i < this.jj_2_rtns.length; ++i) {
            this.jj_2_rtns[i] = new DOTParser.JJCalls();
        }

    }

    public void ReInit(DOTParserTokenManager tm) {
        this.token_source = tm;
        this.token = new Token();
        this.jj_ntk = -1;
        this.jj_gen = 0;

        int i;
        for(i = 0; i < 22; ++i) {
            this.jj_la1[i] = -1;
        }

        for(i = 0; i < this.jj_2_rtns.length; ++i) {
            this.jj_2_rtns[i] = new DOTParser.JJCalls();
        }

    }

    private Token jj_consume_token(int kind) throws ParseException {
        Token oldToken;
        if ((oldToken = this.token).next != null) {
            this.token = this.token.next;
        } else {
            this.token = this.token.next = this.token_source.getNextToken();
        }

        this.jj_ntk = -1;
        if (this.token.kind != kind) {
            this.token = oldToken;
            this.jj_kind = kind;
            throw this.generateParseException();
        } else {
            ++this.jj_gen;
            if (++this.jj_gc > 100) {
                this.jj_gc = 0;

                for(int i = 0; i < this.jj_2_rtns.length; ++i) {
                    for(DOTParser.JJCalls c = this.jj_2_rtns[i]; c != null; c = c.next) {
                        if (c.gen < this.jj_gen) {
                            c.first = null;
                        }
                    }
                }
            }

            return this.token;
        }
    }


    public final Token getNextToken() {
        if (this.token.next != null) {
            this.token = this.token.next;
        } else {
            this.token = this.token.next = this.token_source.getNextToken();
        }

        this.jj_ntk = -1;
        ++this.jj_gen;
        return this.token;
    }

    public final Token getToken(int index) {
        Token t = this.token;

        for(int i = 0; i < index; ++i) {
            if (t.next != null) {
                t = t.next;
            } else {
                t = t.next = this.token_source.getNextToken();
            }
        }

        return t;
    }

    private int jj_ntk() {
        return (this.jj_nt = this.token.next) == null ? (this.jj_ntk = (this.token.next = this.token_source.getNextToken()).kind) : (this.jj_ntk = this.jj_nt.kind);
    }

    private void jj_add_error_token(int kind, int pos) {
        if (pos < 100) {
            if (pos == this.jj_endpos + 1) {
                this.jj_lasttokens[this.jj_endpos++] = kind;
            } else if (this.jj_endpos != 0) {
                this.jj_expentry = new int[this.jj_endpos];

                for(int i = 0; i < this.jj_endpos; ++i) {
                    this.jj_expentry[i] = this.jj_lasttokens[i];
                }

                Iterator it = this.jj_expentries.iterator();

                label41:
                while(true) {
                    int[] oldentry;
                    do {
                        if (!it.hasNext()) {
                            break label41;
                        }

                        oldentry = (int[])((int[])it.next());
                    } while(oldentry.length != this.jj_expentry.length);

                    for(int i = 0; i < this.jj_expentry.length; ++i) {
                        if (oldentry[i] != this.jj_expentry[i]) {
                            continue label41;
                        }
                    }

                    this.jj_expentries.add(this.jj_expentry);
                    break;
                }

                if (pos != 0) {
                    this.jj_lasttokens[(this.jj_endpos = pos) - 1] = kind;
                }
            }

        }
    }

    public ParseException generateParseException() {
        this.jj_expentries.clear();
        boolean[] la1tokens = new boolean[38];
        if (this.jj_kind >= 0) {
            la1tokens[this.jj_kind] = true;
            this.jj_kind = -1;
        }

        int i;
        int j;
        for(i = 0; i < 22; ++i) {
            if (this.jj_la1[i] == this.jj_gen) {
                for(j = 0; j < 32; ++j) {
                    if ((jj_la1_0[i] & 1 << j) != 0) {
                        la1tokens[j] = true;
                    }

                    if ((jj_la1_1[i] & 1 << j) != 0) {
                        la1tokens[32 + j] = true;
                    }
                }
            }
        }

        for(i = 0; i < 38; ++i) {
            if (la1tokens[i]) {
                this.jj_expentry = new int[1];
                this.jj_expentry[0] = i;
                this.jj_expentries.add(this.jj_expentry);
            }
        }

        this.jj_endpos = 0;
        this.jj_rescan_token();
        this.jj_add_error_token(0, 0);
        int[][] exptokseq = new int[this.jj_expentries.size()][];

        for(j = 0; j < this.jj_expentries.size(); ++j) {
            exptokseq[j] = (int[])this.jj_expentries.get(j);
        }

        return new ParseException(this.token, exptokseq, tokenImage);
    }

    public final void enable_tracing() {
    }

    public final void disable_tracing() {
    }

    private void jj_rescan_token() {
        this.jj_rescan = true;

        for(int i = 0; i < 2; ++i) {
            try {
                DOTParser.JJCalls p = this.jj_2_rtns[i];

                do {
                    if (p.gen > this.jj_gen) {
                        this.jj_la = p.arg;
                        this.jj_lastpos = this.jj_scanpos = p.first;
                        switch(i) {
                            case 0:
                                this.jj_3_1();
                                break;
                            case 1:
                                this.jj_3_2();
                        }
                    }

                    p = p.next;
                } while(p != null);
            } catch (DOTParser.LookaheadSuccess var3) {
            }
        }

        this.jj_rescan = false;
    }

    private void jj_save(int index, int xla) {
        DOTParser.JJCalls p;
        for(p = this.jj_2_rtns[index]; p.gen > this.jj_gen; p = p.next) {
            if (p.next == null) {
                p = p.next = new DOTParser.JJCalls();
                break;
            }
        }

        p.gen = this.jj_gen + xla - this.jj_la;
        p.first = this.token;
        p.arg = xla;
    }

    static {
        jj_la1_init_0();
        jj_la1_init_1();
    }

    static final class JJCalls {
        int gen;
        Token first;
        int arg;
        DOTParser.JJCalls next;

        JJCalls() {
        }
    }

    private static final class LookaheadSuccess extends Error {
        private LookaheadSuccess() {
        }
    }
}
