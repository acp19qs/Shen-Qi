package org.graphstream.stream.file;

import org.graphstream.stream.file.tlp.TLPParserTokenManager;
import org.graphstream.util.parser.Token;

import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

public class ParserBase {
    int kind;
    private Token jj_scanpos;
    private Token jj_lastpos;
    private int jj_la;
    private boolean jj_rescan;
    public Token token;
    public LookaheadSuccess jj_ls;
    public TLPParserTokenManager token_source;
    private int jj_endpos;
    private int[] jj_lasttokens;
    private int[] jj_expentry;
    private List<int[]> jj_expentries;


    public ParserBase(LookaheadSuccess jj_ls) {
        this.jj_ls = jj_ls;
    }

    public ParserBase(InputStream stream, String encoding) {
        this.jj_ls = jj_ls;
        this.jj_rescan = false;
        this.jj_ls = new ParserBase.LookaheadSuccess();

    }



    public boolean jj_scan_token(int kind) {
        if (this.jj_scanpos == this.jj_lastpos) {
            --this.jj_la;
            if (this.jj_scanpos.next == null) {
                this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken();
            } else {
                this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next;
            }
        } else {
            this.jj_scanpos = this.jj_scanpos.next;
        }

        if (this.jj_rescan) {
            int i = 0;

            Token tok;
            for(tok = this.token; tok != null && tok != this.jj_scanpos; tok = tok.next) {
                ++i;
            }

            if (tok != null) {
                this.jj_add_error_token(kind, i);
            }
        }

        if (this.jj_scanpos.kind != kind) {
            return true;
        } else if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) {
            throw this.jj_ls;
        } else {
            return false;
        }
    }

    protected static final class LookaheadSuccess extends Error {
        private static final long serialVersionUID = -7986896058452164869L;
        public LookaheadSuccess() {
        }
    }
    private void jj_add_error_token(int kind, int pos) {
        if (pos < 100) {
            if (pos == this.jj_endpos + 1) {
                this.jj_lasttokens[this.jj_endpos++] = kind;
            } else if (this.jj_endpos != 0) {
                this.jj_expentry = new int[this.jj_endpos];

                for(int i = 0; i < this.jj_endpos; ++i) {
                    this.jj_expentry[i] = this.jj_lasttokens[i];
                }

                Iterator it = this.jj_expentries.iterator();

                label41:
                while(true) {
                    int[] oldentry;
                    do {
                        if (!it.hasNext()) {
                            break label41;
                        }

                        oldentry = (int[])((int[])it.next());
                    } while(oldentry.length != this.jj_expentry.length);

                    for(int i = 0; i < this.jj_expentry.length; ++i) {
                        if (oldentry[i] != this.jj_expentry[i]) {
                            continue label41;
                        }
                    }

                    this.jj_expentries.add(this.jj_expentry);
                    break;
                }

                if (pos != 0) {
                    this.jj_lasttokens[(this.jj_endpos = pos) - 1] = kind;
                }
            }

        }
    }

}
