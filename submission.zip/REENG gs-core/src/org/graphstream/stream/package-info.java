
package org.graphstream.stream;