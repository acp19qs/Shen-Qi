
package org.graphstream.graph;