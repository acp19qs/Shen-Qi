
package org.graphstream.graph.implementations;