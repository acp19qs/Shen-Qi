.
|-- COPYING
|-- LICENSE.CECILL-C
|-- LICENSE.LGPL
|-- README.md
|-- bin
|   `-- org
|       `-- graphstream
|           |-- graph
|           |   |-- BreadthFirstIterator.class
|           |   |-- CompoundAttribute.class
|           |   |-- DepthFirstIterator.class
|           |   |-- Edge.class
|           |   |-- EdgeFactory.class
|           |   |-- EdgeRejectedException.class
|           |   |-- Element.class
|           |   |-- ElementNotFoundException.class
|           |   |-- Graph.class
|           |   |-- GraphFactory.class
|           |   |-- IdAlreadyInUseException.class
|           |   |-- Node.class
|           |   |-- NodeFactory.class
|           |   |-- Path.class
|           |   |-- Structure.class
|           |   `-- implementations
|           |       |-- AbstractEdge.class
|           |       |-- AbstractElement$AttributeChangeEvent.class
|           |       |-- AbstractElement.class
|           |       |-- AbstractGraph$GraphReplayController.class
|           |       |-- AbstractGraph.class
|           |       |-- AbstractNode.class
|           |       |-- AdjacencyListGraph$1.class
|           |       |-- AdjacencyListGraph$2.class
|           |       |-- AdjacencyListGraph$EdgeIterator.class
|           |       |-- AdjacencyListGraph$NodeIterator.class
|           |       |-- AdjacencyListGraph.class
|           |       |-- AdjacencyListNode$EdgeIterator.class
|           |       |-- AdjacencyListNode.class
|           |       |-- DefaultGraph.class
|           |       |-- Graphs$SynchronizedEdge.class
|           |       |-- Graphs$SynchronizedElement.class
|           |       |-- Graphs$SynchronizedGraph.class
|           |       |-- Graphs$SynchronizedNode.class
|           |       |-- Graphs.class
|           |       |-- MultiGraph$1.class
|           |       |-- MultiGraph.class
|           |       |-- MultiNode.class
|           |       |-- OneAttributeElement$AttributeChangeEvent.class
|           |       |-- OneAttributeElement.class
|           |       |-- SingleGraph$1.class
|           |       |-- SingleGraph.class
|           |       |-- SingleNode$TwoEdges.class
|           |       `-- SingleNode.class
|           |-- stream
|           |   |-- AnnotatedSink$1.class
|           |   |-- AnnotatedSink$Bind.class
|           |   |-- AnnotatedSink$MethodMap.class
|           |   |-- AnnotatedSink.class
|           |   |-- AttributePipe$FalsePredicate.class
|           |   |-- AttributePipe.class
|           |   |-- AttributePredicate.class
|           |   |-- AttributeSink.class
|           |   |-- ElementSink.class
|           |   |-- GraphParseException.class
|           |   |-- GraphReplay.class
|           |   |-- Pipe.class
|           |   |-- PipeAdapter.class
|           |   |-- PipeBase.class
|           |   |-- ProxyPipe.class
|           |   |-- Replayable$Controller.class
|           |   |-- Replayable.class
|           |   |-- Sink.class
|           |   |-- SinkAdapter.class
|           |   |-- Source.class
|           |   |-- SourceAdapter.class
|           |   |-- SourceBase$1.class
|           |   |-- SourceBase$AddToListEvent.class
|           |   |-- SourceBase$AfterEdgeAddEvent.class
|           |   |-- SourceBase$AfterNodeAddEvent.class
|           |   |-- SourceBase$AttributeChangedEvent.class
|           |   |-- SourceBase$BeforeEdgeRemoveEvent.class
|           |   |-- SourceBase$BeforeGraphClearEvent.class
|           |   |-- SourceBase$BeforeNodeRemoveEvent.class
|           |   |-- SourceBase$ClearListEvent.class
|           |   |-- SourceBase$ElementType.class
|           |   |-- SourceBase$GraphEvent.class
|           |   |-- SourceBase$RemoveFromListEvent.class
|           |   |-- SourceBase$StepBeginsEvent.class
|           |   |-- SourceBase.class
|           |   |-- Timeline$Connector.class
|           |   |-- Timeline$StepDiff.class
|           |   |-- Timeline$TimelineIterator.class
|           |   |-- Timeline$TimelineReplayController.class
|           |   |-- Timeline.class
|           |   |-- binary
|           |   |   |-- ByteDecoder.class
|           |   |   |-- ByteEncoder$Transport.class
|           |   |   |-- ByteEncoder.class
|           |   |   |-- ByteFactory.class
|           |   |   |-- ByteProxy$1.class
|           |   |   |-- ByteProxy$2.class
|           |   |   |-- ByteProxy$3.class
|           |   |   |-- ByteProxy$4.class
|           |   |   |-- ByteProxy$Mode.class
|           |   |   `-- ByteProxy.class
|           |   |-- file
|           |   |   |-- FileSink.class
|           |   |   |-- FileSinkBase.class
|           |   |   |-- FileSinkBaseFiltered.class
|           |   |   |-- FileSinkDGS.class
|           |   |   |-- FileSinkDGSFiltered.class
|           |   |   |-- FileSinkDGSUtility.class
|           |   |   |-- FileSinkDOT$What.class
|           |   |   |-- FileSinkDOT.class
|           |   |   |-- FileSinkDynamicGML.class
|           |   |   |-- FileSinkFactory.class
|           |   |   |-- FileSinkGEXF$GEXFAttribute.class
|           |   |   |-- FileSinkGEXF$GEXFAttributeMap.class
|           |   |   |-- FileSinkGEXF$TimeFormat.class
|           |   |   |-- FileSinkGEXF.class
|           |   |   |-- FileSinkGEXF2$Context.class
|           |   |   |-- FileSinkGEXF2.class
|           |   |   |-- FileSinkGML.class
|           |   |   |-- FileSinkGraphML.class
|           |   |   |-- FileSinkImages$1.class
|           |   |   |-- FileSinkImages$InnerLayoutRunner.class
|           |   |   |-- FileSinkImages$LayoutPolicy.class
|           |   |   |-- FileSinkImages$Option.class
|           |   |   |-- FileSinkImages$OutputPolicy.class
|           |   |   |-- FileSinkImages$OutputRunner.class
|           |   |   |-- FileSinkImages$OutputType.class
|           |   |   |-- FileSinkImages$Quality.class
|           |   |   |-- FileSinkImages.class
|           |   |   |-- FileSinkSVG$What.class
|           |   |   |-- FileSinkSVG.class
|           |   |   |-- FileSinkSVG2$1.class
|           |   |   |-- FileSinkSVG2$SVGContext.class
|           |   |   |-- FileSinkSVG2$SVGStyle.class
|           |   |   |-- FileSinkSVG2$ViewBox.class
|           |   |   |-- FileSinkSVG2$XMLWriter.class
|           |   |   |-- FileSinkSVG2.class
|           |   |   |-- FileSinkTikZ$1.class
|           |   |   |-- FileSinkTikZ$PointsWrapper.class
|           |   |   |-- FileSinkTikZ.class
|           |   |   |-- FileSource.class
|           |   |   |-- FileSourceBase$CurrentFile.class
|           |   |   |-- FileSourceBase.class
|           |   |   |-- FileSourceDGS$1.class
|           |   |   |-- FileSourceDGS.class
|           |   |   |-- FileSourceDGS1And2$AttributeFormat.class
|           |   |   |-- FileSourceDGS1And2$AttributeType.class
|           |   |   |-- FileSourceDGS1And2.class
|           |   |   |-- FileSourceDOT$1.class
|           |   |   |-- FileSourceDOT.class
|           |   |   |-- FileSourceEdge.class
|           |   |   |-- FileSourceFactory.class
|           |   |   |-- FileSourceGEXF$1.class
|           |   |   |-- FileSourceGEXF$Attribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$ATTRIBUTEAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$ATTRIBUTESAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$ATTVALUEAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$AttributeType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$Balise.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$COLORAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$ClassType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$EDGEAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$EDGESAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$EDGESHAPEAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$EdgeShapeType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$EdgeType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$GEXFAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$GRAPHAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$IDType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$METAAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$ModeType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$NODEAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$NODESAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$NODESHAPEAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$NodeShapeType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$PARENTAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$POSITIONAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$SIZEAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$SPELLAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$THICKNESSAttribute.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$TimeFormatType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants$WeightType.class
|           |   |   |-- FileSourceGEXF$GEXFConstants.class
|           |   |   |-- FileSourceGEXF$GEXFParser.class
|           |   |   |-- FileSourceGEXF.class
|           |   |   |-- FileSourceGML$1.class
|           |   |   |-- FileSourceGML.class
|           |   |   |-- FileSourceGPX$GPXConstants$BOUNDSAttribute.class
|           |   |   |-- FileSourceGPX$GPXConstants$Balise.class
|           |   |   |-- FileSourceGPX$GPXConstants$COPYRIGHTAttribute.class
|           |   |   |-- FileSourceGPX$GPXConstants$EMAILAttribute.class
|           |   |   |-- FileSourceGPX$GPXConstants$FixType.class
|           |   |   |-- FileSourceGPX$GPXConstants$GPXAttribute.class
|           |   |   |-- FileSourceGPX$GPXConstants$LINKAttribute.class
|           |   |   |-- FileSourceGPX$GPXConstants$PTAttribute.class
|           |   |   |-- FileSourceGPX$GPXConstants$WPTAttribute.class
|           |   |   |-- FileSourceGPX$GPXConstants.class
|           |   |   |-- FileSourceGPX$GPXParser.class
|           |   |   |-- FileSourceGPX$WayPoint.class
|           |   |   |-- FileSourceGPX.class
|           |   |   |-- FileSourceGraphML$1.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$Balise.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$Data.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$DataAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$EdgeAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$EndPoint.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$EndPointAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$EndPointType.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$GraphAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$HyperEdgeAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$Key.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$KeyAttrType.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$KeyAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$KeyDomain.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$Locator.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$LocatorAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$NodeAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$Port.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants$PortAttribute.class
|           |   |   |-- FileSourceGraphML$GraphMLConstants.class
|           |   |   |-- FileSourceGraphML$GraphMLParser.class
|           |   |   |-- FileSourceGraphML.class
|           |   |   |-- FileSourceLGL.class
|           |   |   |-- FileSourceNCol.class
|           |   |   |-- FileSourcePajek$1.class
|           |   |   |-- FileSourcePajek.class
|           |   |   |-- FileSourceParser.class
|           |   |   |-- FileSourceTLP$1.class
|           |   |   |-- FileSourceTLP.class
|           |   |   |-- FileSourceXML$Parser.class
|           |   |   |-- FileSourceXML.class
|           |   |   |-- dgs
|           |   |   |   |-- DGSParser$1.class
|           |   |   |   |-- DGSParser$Token.class
|           |   |   |   |-- DGSParser.class
|           |   |   |   `-- OldFileSourceDGS.class
|           |   |   |-- dot
|           |   |   |   |-- DOTParser$1.class
|           |   |   |   |-- DOTParser$JJCalls.class
|           |   |   |   |-- DOTParser$LookaheadSuccess.class
|           |   |   |   |-- DOTParser.class
|           |   |   |   |-- DOTParserConstants.class
|           |   |   |   `-- DOTParserTokenManager.class
|           |   |   |-- gexf
|           |   |   |   |-- GEXF.class
|           |   |   |   |-- GEXFAttValue.class
|           |   |   |   |-- GEXFAttValues.class
|           |   |   |   |-- GEXFAttribute.class
|           |   |   |   |-- GEXFAttributes.class
|           |   |   |   |-- GEXFEdge.class
|           |   |   |   |-- GEXFEdges.class
|           |   |   |   |-- GEXFElement$AttrType.class
|           |   |   |   |-- GEXFElement$ClassType.class
|           |   |   |   |-- GEXFElement$DefaultEdgeType.class
|           |   |   |   |-- GEXFElement$Extension.class
|           |   |   |   |-- GEXFElement$IDType.class
|           |   |   |   |-- GEXFElement$Mode.class
|           |   |   |   |-- GEXFElement$TimeFormat.class
|           |   |   |   |-- GEXFElement.class
|           |   |   |   |-- GEXFGraph.class
|           |   |   |   |-- GEXFMeta.class
|           |   |   |   |-- GEXFNode.class
|           |   |   |   |-- GEXFNodes.class
|           |   |   |   |-- GEXFSpell.class
|           |   |   |   |-- GEXFSpells.class
|           |   |   |   `-- SmartXMLWriter.class
|           |   |   |-- gml
|           |   |   |   |-- GMLContext.class
|           |   |   |   |-- GMLParser.class
|           |   |   |   |-- GMLParserConstants.class
|           |   |   |   |-- GMLParserTokenManager.class
|           |   |   |   |-- Graphics.class
|           |   |   |   `-- KeyValues.class
|           |   |   |-- images
|           |   |   |   |-- CustomResolution.class
|           |   |   |   |-- FileSinkImagesFactory.class
|           |   |   |   |-- Filter.class
|           |   |   |   |-- Resolution.class
|           |   |   |   |-- Resolutions.class
|           |   |   |   `-- filters
|           |   |   |       `-- AddLogoFilter.class
|           |   |   |-- pajek
|           |   |   |   |-- EdgeGraphics.class
|           |   |   |   |-- EdgeMatrix.class
|           |   |   |   |-- Graphics.class
|           |   |   |   |-- NodeGraphics.class
|           |   |   |   |-- PajekContext.class
|           |   |   |   |-- PajekParser$1.class
|           |   |   |   |-- PajekParser$JJCalls.class
|           |   |   |   |-- PajekParser$LookaheadSuccess.class
|           |   |   |   |-- PajekParser.class
|           |   |   |   |-- PajekParserConstants.class
|           |   |   |   `-- PajekParserTokenManager.class
|           |   |   `-- tlp
|           |   |       |-- TLPParser$1.class
|           |   |       |-- TLPParser$Cluster.class
|           |   |       |-- TLPParser$JJCalls.class
|           |   |       |-- TLPParser$LookaheadSuccess.class
|           |   |       |-- TLPParser$PropertyType.class
|           |   |       |-- TLPParser.class
|           |   |       |-- TLPParserConstants.class
|           |   |       `-- TLPParserTokenManager.class
|           |   |-- net
|           |   |   `-- URLSource.class
|           |   |-- netstream
|           |   |   |-- NetStreamConstants.class
|           |   |   |-- NetStreamDecoder.class
|           |   |   |-- NetStreamEncoder.class
|           |   |   |-- NetStreamUtils$1.class
|           |   |   `-- NetStreamUtils.class
|           |   |-- rmi
|           |   |   |-- RMIAdapterIn.class
|           |   |   |-- RMIAdapterOut.class
|           |   |   |-- RMISink.class
|           |   |   `-- RMISource.class
|           |   |-- sync
|           |   |   |-- SinkTime.class
|           |   |   `-- SourceTime.class
|           |   `-- thread
|           |       |-- ThreadProxyPipe$1.class
|           |       |-- ThreadProxyPipe$GraphEvents.class
|           |       `-- ThreadProxyPipe.class
|           |-- ui
|           |   |-- geom
|           |   |   |-- Point2.class
|           |   |   |-- Point3.class
|           |   |   |-- Vector2.class
|           |   |   `-- Vector3.class
|           |   |-- graphicGraph
|           |   |   |-- GraphPosLengthUtils.class
|           |   |   |-- GraphicEdge$EdgeGroup.class
|           |   |   |-- GraphicEdge.class
|           |   |   |-- GraphicElement$SwingElementRenderer.class
|           |   |   |-- GraphicElement.class
|           |   |   |-- GraphicElementChangeListener.class
|           |   |   |-- GraphicGraph.class
|           |   |   |-- GraphicNode.class
|           |   |   |-- GraphicSprite.class
|           |   |   |-- StyleGroup$BulkElements.class
|           |   |   |-- StyleGroup$BulkIterator.class
|           |   |   |-- StyleGroup$ElementEvents.class
|           |   |   |-- StyleGroup.class
|           |   |   |-- StyleGroupListener.class
|           |   |   |-- StyleGroupSet$1.class
|           |   |   |-- StyleGroupSet$EdgeSet.class
|           |   |   |-- StyleGroupSet$ElementIterator.class
|           |   |   |-- StyleGroupSet$EventSet.class
|           |   |   |-- StyleGroupSet$GraphSet.class
|           |   |   |-- StyleGroupSet$NodeSet.class
|           |   |   |-- StyleGroupSet$ShadowSet.class
|           |   |   |-- StyleGroupSet$SpriteSet.class
|           |   |   |-- StyleGroupSet$ZIndex$ZIndexIterator.class
|           |   |   |-- StyleGroupSet$ZIndex.class
|           |   |   |-- StyleGroupSet.class
|           |   |   `-- stylesheet
|           |   |       |-- Color.class
|           |   |       |-- Colors.class
|           |   |       |-- Rule.class
|           |   |       |-- Selector$Type.class
|           |   |       |-- Selector.class
|           |   |       |-- Style.class
|           |   |       |-- StyleConstants$ArrowShape.class
|           |   |       |-- StyleConstants$FillMode.class
|           |   |       |-- StyleConstants$IconMode.class
|           |   |       |-- StyleConstants$JComponents.class
|           |   |       |-- StyleConstants$ShadowMode.class
|           |   |       |-- StyleConstants$Shape.class
|           |   |       |-- StyleConstants$ShapeKind.class
|           |   |       |-- StyleConstants$SizeMode.class
|           |   |       |-- StyleConstants$SpriteOrientation.class
|           |   |       |-- StyleConstants$StrokeMode.class
|           |   |       |-- StyleConstants$TextAlignment.class
|           |   |       |-- StyleConstants$TextBackgroundMode.class
|           |   |       |-- StyleConstants$TextMode.class
|           |   |       |-- StyleConstants$TextStyle.class
|           |   |       |-- StyleConstants$TextVisibilityMode.class
|           |   |       |-- StyleConstants$Units.class
|           |   |       |-- StyleConstants$VisibilityMode.class
|           |   |       |-- StyleConstants.class
|           |   |       |-- StyleSheet$1.class
|           |   |       |-- StyleSheet$NameSpace.class
|           |   |       |-- StyleSheet.class
|           |   |       |-- StyleSheetListener.class
|           |   |       |-- Value$1.class
|           |   |       |-- Value.class
|           |   |       |-- Values$1.class
|           |   |       |-- Values.class
|           |   |       |-- parser
|           |   |       |   |-- StyleSheetParser$Number.class
|           |   |       |   |-- StyleSheetParser.class
|           |   |       |   |-- StyleSheetParserConstants.class
|           |   |       |   `-- StyleSheetParserTokenManager.class
|           |   |       `-- rgb.properties
|           |   |-- layout
|           |   |   |-- Layout.class
|           |   |   |-- LayoutRunner.class
|           |   |   |-- Layouts.class
|           |   |   `-- springbox
|           |   |       |-- BarnesHutLayout.class
|           |   |       |-- EdgeSpring.class
|           |   |       |-- Energies.class
|           |   |       |-- GraphCellData.class
|           |   |       |-- NodeParticle.class
|           |   |       `-- implementations
|           |   |           |-- LinLog.class
|           |   |           |-- LinLogNodeParticle.class
|           |   |           |-- SpringBox.class
|           |   |           `-- SpringBoxNodeParticle.class
|           |   |-- spriteManager
|           |   |   |-- InvalidSpriteIDException.class
|           |   |   |-- Sprite.class
|           |   |   |-- SpriteFactory.class
|           |   |   `-- SpriteManager.class
|           |   `-- view
|           |       |-- GraphRenderer.class
|           |       |-- GraphRendererBase.class
|           |       |-- LayerRenderer.class
|           |       |-- Selection.class
|           |       |-- View.class
|           |       |-- Viewer$CloseFramePolicy.class
|           |       |-- Viewer$ThreadingModel.class
|           |       |-- Viewer.class
|           |       |-- ViewerListener.class
|           |       |-- ViewerPipe.class
|           |       |-- camera
|           |       |   |-- AreaSkeleton.class
|           |       |   |-- Backend.class
|           |       |   |-- Camera.class
|           |       |   |-- ConnectorSkeleton.class
|           |       |   |-- DefaultCamera2D$1.class
|           |       |   |-- DefaultCamera2D.class
|           |       |   `-- Skeleton.class
|           |       `-- util
|           |           |-- FpsCounter.class
|           |           |-- GraphMetrics$1.class
|           |           |-- GraphMetrics.class
|           |           |-- InteractiveElement.class
|           |           |-- MouseManager.class
|           |           `-- ShortcutManager.class
|           `-- util
|               |-- Display.class
|               |-- Environment.class
|               |-- GraphDiff$1.class
|               |-- GraphDiff$AttributeAdded.class
|               |-- GraphDiff$AttributeChanged.class
|               |-- GraphDiff$AttributeRemoved.class
|               |-- GraphDiff$Bridge.class
|               |-- GraphDiff$EdgeAdded.class
|               |-- GraphDiff$EdgeRemoved.class
|               |-- GraphDiff$ElementEvent.class
|               |-- GraphDiff$ElementType.class
|               |-- GraphDiff$Event.class
|               |-- GraphDiff$GraphCleared.class
|               |-- GraphDiff$NodeAdded.class
|               |-- GraphDiff$NodeRemoved.class
|               |-- GraphDiff$StepBegins.class
|               |-- GraphDiff.class
|               |-- GraphListeners.class
|               |-- MissingDisplayException.class
|               |-- StepCounter.class
|               |-- VerboseSink$1.class
|               |-- VerboseSink$Args.class
|               |-- VerboseSink$EventType.class
|               |-- VerboseSink.class
|               |-- cumulative
|               |   |-- CumulativeAttributes.class
|               |   |-- CumulativeSpells$Spell.class
|               |   |-- CumulativeSpells.class
|               |   |-- GraphSpells$EdgeData.class
|               |   `-- GraphSpells.class
|               |-- parser
|               |   |-- ParseException.class
|               |   |-- Parser.class
|               |   |-- ParserFactory.class
|               |   |-- SimpleCharStream.class
|               |   |-- Token.class
|               |   `-- TokenMgrError.class
|               |-- set
|               |   |-- FixedArrayList$FixedArrayIterator.class
|               |   `-- FixedArrayList.class
|               `-- time
|                   |-- ISODateComponent$AMPMComponent.class
|                   |-- ISODateComponent$AliasComponent.class
|                   |-- ISODateComponent$EpochComponent.class
|                   |-- ISODateComponent$FieldComponent.class
|                   |-- ISODateComponent$LocaleDependentComponent.class
|                   |-- ISODateComponent$NotImplementedComponent.class
|                   |-- ISODateComponent$TextComponent.class
|                   |-- ISODateComponent$UTCOffsetComponent.class
|                   |-- ISODateComponent.class
|                   `-- ISODateIO.class
|-- changelog.md
|-- doc
|   `-- stylesheet.css
|-- javadoc.xml
|-- pom.xml
|-- src
|   `-- org
|       `-- graphstream
|           |-- graph
|           |   |-- BreadthFirstIterator.java
|           |   |-- CompoundAttribute.java
|           |   |-- DepthFirstIterator.java
|           |   |-- Edge.java
|           |   |-- EdgeFactory.java
|           |   |-- EdgeRejectedException.java
|           |   |-- Element.java
|           |   |-- ElementNotFoundException.java
|           |   |-- Graph.java
|           |   |-- GraphFactory.java
|           |   |-- IdAlreadyInUseException.java
|           |   |-- Node.java
|           |   |-- NodeFactory.java
|           |   |-- Path.java
|           |   |-- Structure.java
|           |   |-- implementations
|           |   |   |-- AbstractEdge.java
|           |   |   |-- AbstractElement.java
|           |   |   |-- AbstractGraph.java
|           |   |   |-- AbstractNode.java
|           |   |   |-- AdjacencyListGraph.java
|           |   |   |-- AdjacencyListNode.java
|           |   |   |-- DefaultGraph.java
|           |   |   |-- Graphs.java
|           |   |   |-- MultiGraph.java
|           |   |   |-- MultiNode.java
|           |   |   |-- OneAttributeElement.java
|           |   |   |-- SingleGraph.java
|           |   |   |-- SingleNode.java
|           |   |   `-- package-info.java
|           |   `-- package-info.java
|           |-- stream
|           |   |-- AnnotatedSink.java
|           |   |-- AttributePipe.java
|           |   |-- AttributePredicate.java
|           |   |-- AttributeSink.java
|           |   |-- ElementSink.java
|           |   |-- GraphParseException.java
|           |   |-- GraphReplay.java
|           |   |-- Pipe.java
|           |   |-- PipeAdapter.java
|           |   |-- PipeBase.java
|           |   |-- ProxyPipe.java
|           |   |-- Replayable.java
|           |   |-- Sink.java
|           |   |-- SinkAdapter.java
|           |   |-- Source.java
|           |   |-- SourceAdapter.java
|           |   |-- SourceBase.java
|           |   |-- Timeline.java
|           |   |-- binary
|           |   |   |-- ByteDecoder.java
|           |   |   |-- ByteEncoder.java
|           |   |   |-- ByteFactory.java
|           |   |   `-- ByteProxy.java
|           |   |-- file
|           |   |   |-- FileSink.java
|           |   |   |-- FileSinkBase.java
|           |   |   |-- FileSinkBaseFiltered.java
|           |   |   |-- FileSinkDGS.java
|           |   |   |-- FileSinkDGSFiltered.java
|           |   |   |-- FileSinkDGSUtility.java
|           |   |   |-- FileSinkDOT.java
|           |   |   |-- FileSinkDynamicGML.java
|           |   |   |-- FileSinkFactory.java
|           |   |   |-- FileSinkGEXF.java
|           |   |   |-- FileSinkGEXF2.java
|           |   |   |-- FileSinkGML.java
|           |   |   |-- FileSinkGraphML.java
|           |   |   |-- FileSinkImages.java
|           |   |   |-- FileSinkSVG.java
|           |   |   |-- FileSinkSVG2.java
|           |   |   |-- FileSinkTikZ.java
|           |   |   |-- FileSource.java
|           |   |   |-- FileSourceBase.java
|           |   |   |-- FileSourceDGS.java
|           |   |   |-- FileSourceDGS1And2.java
|           |   |   |-- FileSourceDOT.java
|           |   |   |-- FileSourceEdge.java
|           |   |   |-- FileSourceFactory.java
|           |   |   |-- FileSourceGEXF.java
|           |   |   |-- FileSourceGML.java
|           |   |   |-- FileSourceGPX.java
|           |   |   |-- FileSourceGPX.xsd
|           |   |   |-- FileSourceGraphML.java
|           |   |   |-- FileSourceLGL.java
|           |   |   |-- FileSourceNCol.java
|           |   |   |-- FileSourcePajek.java
|           |   |   |-- FileSourceParser.java
|           |   |   |-- FileSourceTLP.java
|           |   |   |-- FileSourceXML.java
|           |   |   |-- dgs
|           |   |   |   |-- DGSParser.java
|           |   |   |   `-- OldFileSourceDGS.java
|           |   |   |-- dot
|           |   |   |   |-- DOTParser.java
|           |   |   |   |-- DOTParser.jj
|           |   |   |   |-- DOTParserConstants.java
|           |   |   |   `-- DOTParserTokenManager.java
|           |   |   |-- gexf
|           |   |   |   |-- GEXF.java
|           |   |   |   |-- GEXFAttValue.java
|           |   |   |   |-- GEXFAttValues.java
|           |   |   |   |-- GEXFAttribute.java
|           |   |   |   |-- GEXFAttributes.java
|           |   |   |   |-- GEXFEdge.java
|           |   |   |   |-- GEXFEdges.java
|           |   |   |   |-- GEXFElement.java
|           |   |   |   |-- GEXFGraph.java
|           |   |   |   |-- GEXFMeta.java
|           |   |   |   |-- GEXFNode.java
|           |   |   |   |-- GEXFNodes.java
|           |   |   |   |-- GEXFSpell.java
|           |   |   |   |-- GEXFSpells.java
|           |   |   |   `-- SmartXMLWriter.java
|           |   |   |-- gml
|           |   |   |   |-- GMLContext.java
|           |   |   |   |-- GMLParser.java
|           |   |   |   |-- GMLParser.jj
|           |   |   |   |-- GMLParserConstants.java
|           |   |   |   `-- GMLParserTokenManager.java
|           |   |   |-- images
|           |   |   |   |-- CustomResolution.java
|           |   |   |   |-- FileSinkImagesFactory.java
|           |   |   |   |-- Filter.java
|           |   |   |   |-- Resolution.java
|           |   |   |   |-- Resolutions.java
|           |   |   |   `-- filters
|           |   |   |       `-- AddLogoFilter.java
|           |   |   |-- pajek
|           |   |   |   |-- PajekContext.java
|           |   |   |   |-- PajekParser.java
|           |   |   |   |-- PajekParser.jj
|           |   |   |   |-- PajekParserConstants.java
|           |   |   |   `-- PajekParserTokenManager.java
|           |   |   `-- tlp
|           |   |       |-- TLPParser.java
|           |   |       |-- TLPParser.jj
|           |   |       |-- TLPParserConstants.java
|           |   |       `-- TLPParserTokenManager.java
|           |   |-- net
|           |   |   `-- URLSource.java
|           |   |-- netstream
|           |   |   |-- NetStreamConstants.java
|           |   |   |-- NetStreamDecoder.java
|           |   |   |-- NetStreamEncoder.java
|           |   |   `-- NetStreamUtils.java
|           |   |-- package-info.java
|           |   |-- rmi
|           |   |   |-- RMIAdapterIn.java
|           |   |   |-- RMIAdapterOut.java
|           |   |   |-- RMISink.java
|           |   |   `-- RMISource.java
|           |   |-- sync
|           |   |   |-- SinkTime.java
|           |   |   `-- SourceTime.java
|           |   `-- thread
|           |       `-- ThreadProxyPipe.java
|           |-- ui
|           |   |-- geom
|           |   |   |-- Point2.java
|           |   |   |-- Point3.java
|           |   |   |-- Vector2.java
|           |   |   `-- Vector3.java
|           |   |-- graphicGraph
|           |   |   |-- GraphPosLengthUtils.java
|           |   |   |-- GraphicEdge.java
|           |   |   |-- GraphicElement.java
|           |   |   |-- GraphicElementChangeListener.java
|           |   |   |-- GraphicGraph.java
|           |   |   |-- GraphicNode.java
|           |   |   |-- GraphicSprite.java
|           |   |   |-- HowItWorks.mkd
|           |   |   |-- StyleGroup.java
|           |   |   |-- StyleGroupListener.java
|           |   |   |-- StyleGroupSet.java
|           |   |   |-- package-info.java
|           |   |   `-- stylesheet
|           |   |       |-- Color.java
|           |   |       |-- Colors.java
|           |   |       |-- HowItWorks.mkd
|           |   |       |-- Rule.java
|           |   |       |-- Selector.java
|           |   |       |-- Style.java
|           |   |       |-- StyleConstants.java
|           |   |       |-- StyleSheet.java
|           |   |       |-- StyleSheetListener.java
|           |   |       |-- The_GraphStream_CSS
|           |   |       |-- The_GraphStream_CSS_Dyn
|           |   |       |-- Value.java
|           |   |       |-- Values.java
|           |   |       |-- package-info.java
|           |   |       |-- parser
|           |   |       |   |-- StyleSheetParser.java
|           |   |       |   |-- StyleSheetParser.jj
|           |   |       |   |-- StyleSheetParserConstants.java
|           |   |       |   |-- StyleSheetParserTokenManager.java
|           |   |       |   `-- package-info.java
|           |   |       `-- rgb.properties
|           |   |-- layout
|           |   |   |-- Layout.java
|           |   |   |-- LayoutRunner.java
|           |   |   |-- Layouts.java
|           |   |   |-- package-info.java
|           |   |   `-- springbox
|           |   |       |-- BarnesHutLayout.java
|           |   |       |-- EdgeSpring.java
|           |   |       |-- Energies.java
|           |   |       |-- GraphCellData.java
|           |   |       |-- HowItWorks.rst
|           |   |       |-- NodeParticle.java
|           |   |       `-- implementations
|           |   |           |-- LinLog.java
|           |   |           |-- LinLogNodeParticle.java
|           |   |           |-- SpringBox.java
|           |   |           `-- SpringBoxNodeParticle.java
|           |   |-- spriteManager
|           |   |   |-- InvalidSpriteIDException.java
|           |   |   |-- Sprite.java
|           |   |   |-- SpriteFactory.java
|           |   |   `-- SpriteManager.java
|           |   `-- view
|           |       |-- GraphRenderer.java
|           |       |-- GraphRendererBase.java
|           |       |-- HowItWorks
|           |       |-- LayerRenderer.java
|           |       |-- Selection.java
|           |       |-- View.java
|           |       |-- Viewer.java
|           |       |-- ViewerListener.java
|           |       |-- ViewerPipe.java
|           |       |-- camera
|           |       |   |-- AreaSkeleton.java
|           |       |   |-- Backend.java
|           |       |   |-- Camera.java
|           |       |   |-- ConnectorSkeleton.java
|           |       |   |-- DefaultCamera2D.java
|           |       |   `-- Skeleton.java
|           |       `-- util
|           |           |-- FpsCounter.java
|           |           |-- GraphMetrics.java
|           |           |-- InteractiveElement.java
|           |           |-- MouseManager.java
|           |           `-- ShortcutManager.java
|           `-- util
|               |-- Display.java
|               |-- Environment.java
|               |-- GraphDiff.java
|               |-- GraphListeners.java
|               |-- MissingDisplayException.java
|               |-- StepCounter.java
|               |-- VerboseSink.java
|               |-- cumulative
|               |   |-- CumulativeAttributes.java
|               |   |-- CumulativeSpells.java
|               |   `-- GraphSpells.java
|               |-- parser
|               |   |-- ParseException.java
|               |   |-- Parser.java
|               |   |-- ParserFactory.java
|               |   |-- SimpleCharStream.java
|               |   |-- Token.java
|               |   |-- TokenMgrError.java
|               |   `-- template.jj
|               |-- set
|               |   `-- FixedArrayList.java
|               `-- time
|                   |-- ISODateComponent.java
|                   `-- ISODateIO.java
|-- src-test
|   `-- org
|       `-- graphstream
|           |-- graph
|           |   `-- test
|           |       |-- BenchPerformance.java
|           |       |-- TestAbstractElement.java
|           |       |-- TestElement.java
|           |       |-- TestGraph.java
|           |       `-- TestGraphSynchronisation.java
|           |-- stream
|           |   |-- binary
|           |   |   `-- test
|           |   |       `-- ExampleByteProxy.java
|           |   |-- file
|           |   |   |-- dgs
|           |   |   |   `-- test
|           |   |   |       |-- TestDGSParser.java
|           |   |   |       `-- data
|           |   |   |           |-- attributes.dgs
|           |   |   |           |-- attributes_array.dgs
|           |   |   |           |-- bad1.dgs
|           |   |   |           |-- bad2.dgs
|           |   |   |           |-- elements.dgs
|           |   |   |           `-- removeAttribute.dgs
|           |   |   |-- gml
|           |   |   |   `-- test
|           |   |   |       |-- SmallTest.gml
|           |   |   |       |-- TestSinkGML.java
|           |   |   |       |-- TestSourceGML.java
|           |   |   |       |-- dynamic.gml
|           |   |   |       `-- example2.sif.gml
|           |   |   |-- pajek
|           |   |   |   `-- test
|           |   |   |       |-- 1.CLU
|           |   |   |       |-- 1.NET
|           |   |   |       |-- 1CRN.BS
|           |   |   |       |-- 1CRN.MAC
|           |   |   |       |-- 1CRN.NET
|           |   |   |       |-- 1CTX.BS
|           |   |   |       |-- 22.HIE
|           |   |   |       |-- ADF073.MAC
|           |   |   |       |-- ADH008.BS
|           |   |   |       |-- AHO1.NET
|           |   |   |       |-- AHO2.NET
|           |   |   |       |-- AHO3.NET
|           |   |   |       |-- AHO4.NET
|           |   |   |       |-- B.NET
|           |   |   |       |-- BDL011.BS
|           |   |   |       |-- C.NET
|           |   |   |       |-- C6H12.MAC
|           |   |   |       |-- CC.NET
|           |   |   |       |-- CENPROD.NET
|           |   |   |       |-- CIRC.NET
|           |   |   |       |-- CITE.NET
|           |   |   |       |-- CP.NET
|           |   |   |       |-- CPM1.NET
|           |   |   |       |-- CPM2.NET
|           |   |   |       |-- CPM3.NET
|           |   |   |       |-- CVRML.NET
|           |   |   |       |-- CX.NET
|           |   |   |       |-- D.NET
|           |   |   |       |-- D1.EPS
|           |   |   |       |-- DNA.NET
|           |   |   |       |-- DREV1.CLU
|           |   |   |       |-- DREV1.NET
|           |   |   |       |-- DREVO.NET
|           |   |   |       |-- ETHANOL.MAC
|           |   |   |       |-- ETHANOL.NET
|           |   |   |       |-- FILE1.NET
|           |   |   |       |-- FLOW.NET
|           |   |   |       |-- FLOW3.NET
|           |   |   |       |-- FLOW4.NET
|           |   |   |       |-- FRAG1.NET
|           |   |   |       |-- FRAG1X.NET
|           |   |   |       |-- FRAG1Y.NET
|           |   |   |       |-- FRAG2.NET
|           |   |   |       |-- FRAG3.NET
|           |   |   |       |-- FRAG4.NET
|           |   |   |       |-- FRAG5.NET
|           |   |   |       |-- GCD.NET
|           |   |   |       |-- GR344.NET
|           |   |   |       |-- GR3_44.NET
|           |   |   |       |-- GR3_53.NET
|           |   |   |       |-- GR3_60.NET
|           |   |   |       |-- GR3_81.NET
|           |   |   |       |-- H20.MAC
|           |   |   |       |-- H20.NET
|           |   |   |       |-- H2O.MAC
|           |   |   |       |-- HEXANE.MAC
|           |   |   |       |-- HEXANE.NET
|           |   |   |       |-- KOCKA.NET
|           |   |   |       |-- KOCKA1.NET
|           |   |   |       |-- KVADRAT.NET
|           |   |   |       |-- LINKS.NET
|           |   |   |       |-- LOND1.NET
|           |   |   |       |-- LONDON.NET
|           |   |   |       |-- MCCABE1.CLU
|           |   |   |       |-- MCCABE1.NET
|           |   |   |       |-- MCCABE1A.NET
|           |   |   |       |-- MCCABE2.CLU
|           |   |   |       |-- MCCABE2.NET
|           |   |   |       |-- MCCABE2A.NET
|           |   |   |       |-- MREZA.NET
|           |   |   |       |-- MREZA.PER
|           |   |   |       |-- MREZA1.NET
|           |   |   |       |-- MREZA1.PER
|           |   |   |       |-- MREZA2.NET
|           |   |   |       |-- MREZA3.NET
|           |   |   |       |-- MREZAS1.NET
|           |   |   |       |-- MREZASHR.NET
|           |   |   |       |-- NEG.CLU
|           |   |   |       |-- NEG.NET
|           |   |   |       |-- NEIG4.NET
|           |   |   |       |-- NOOY.CLU
|           |   |   |       |-- NOOY.NET
|           |   |   |       |-- OLDFILE.NET
|           |   |   |       |-- PATH4.NET
|           |   |   |       |-- PER.PER
|           |   |   |       |-- PETER.NET
|           |   |   |       |-- PETRI1.CLU
|           |   |   |       |-- PETRI1.NET
|           |   |   |       |-- PETRI2.CLU
|           |   |   |       |-- PETRI2.NET
|           |   |   |       |-- PETRI21.CLU
|           |   |   |       |-- PETRI22.CLU
|           |   |   |       |-- PETRI3.CLU
|           |   |   |       |-- PETRI3.NET
|           |   |   |       |-- PETRI4.CLU
|           |   |   |       |-- PETRI4.NET
|           |   |   |       |-- PETRI5.CLU
|           |   |   |       |-- PETRI5.NET
|           |   |   |       |-- PETRI51.CLU
|           |   |   |       |-- PETRI51.NET
|           |   |   |       |-- PETRI51X.NET
|           |   |   |       |-- PETRI51Y.NET
|           |   |   |       |-- PETRI52.CLU
|           |   |   |       |-- PETRI52.NET
|           |   |   |       |-- PETRI52X.NET
|           |   |   |       |-- PETRI52Y.NET
|           |   |   |       |-- PETRI53.NET
|           |   |   |       |-- PETRI5X.NET
|           |   |   |       |-- PETRI5Y.NET
|           |   |   |       |-- PITT.NET
|           |   |   |       |-- PRIME.NET
|           |   |   |       |-- PRIME1.NET
|           |   |   |       |-- PROT.NET
|           |   |   |       |-- PROTI.NET
|           |   |   |       |-- SAMPLE10.NET
|           |   |   |       |-- SAMPLE6.NET
|           |   |   |       |-- SAMPLE9.NET
|           |   |   |       |-- SHAPES.CFG
|           |   |   |       |-- SHORT.NET
|           |   |   |       |-- SHR.HIE
|           |   |   |       |-- SHR.NET
|           |   |   |       |-- SHR.PER
|           |   |   |       |-- SHRINK.CLS
|           |   |   |       |-- SHRINK.CLU
|           |   |   |       |-- SHRINK.HIE
|           |   |   |       |-- SHRINK.NET
|           |   |   |       |-- SHRINK.PER
|           |   |   |       |-- SHRINK1.CLU
|           |   |   |       |-- SHRINK1.HIE
|           |   |   |       |-- SHRINK1.NET
|           |   |   |       |-- SHRINK2.HIE
|           |   |   |       |-- SHRINK2.NET
|           |   |   |       |-- SHRINK4.NET
|           |   |   |       |-- SLOVEN.NET
|           |   |   |       |-- STROPIC.NET
|           |   |   |       |-- T.NET
|           |   |   |       |-- TEST1.NET
|           |   |   |       |-- TINA.NET
|           |   |   |       |-- TINA1.CLU
|           |   |   |       |-- TINA1.HIE
|           |   |   |       |-- TINA2.CLU
|           |   |   |       |-- TINA2.HIE
|           |   |   |       |-- TINAMATR.NET
|           |   |   |       |-- TRANS.NET
|           |   |   |       |-- TRANS1.CLU
|           |   |   |       |-- TRANS2.CLU
|           |   |   |       |-- TestPajekParser.java
|           |   |   |       |-- WHITT.NET
|           |   |   |       |-- WIRTH.CLU
|           |   |   |       |-- WIRTH.NET
|           |   |   |       |-- WRITE.CLU
|           |   |   |       |-- WRITE.NET
|           |   |   |       |-- WRITE.PER
|           |   |   |       `-- WRITE1.CLU
|           |   |   `-- test
|           |   |       |-- TestFileSinkBase.java
|           |   |       |-- TestFileSinkDGS.java
|           |   |       |-- TestFileSinkDOT.java
|           |   |       |-- TestFileSinkGraphML.java
|           |   |       |-- TestFileSourceBase.java
|           |   |       |-- TestFileSourceDGS.java
|           |   |       |-- TestFileSourceDOT.java
|           |   |       |-- TestFileSourceEdge.java
|           |   |       |-- TestFileSourceGEXF.java
|           |   |       |-- TestFileSourceGML.java
|           |   |       |-- TestFileSourceGraphML.java
|           |   |       `-- data
|           |   |           |-- basic.gexf
|           |   |           |-- data.gexf
|           |   |           |-- example-extraattributes.graphml
|           |   |           |-- example.graphml
|           |   |           |-- undirectedTriangle.dgs
|           |   |           |-- undirectedTriangle.dot
|           |   |           |-- undirectedTriangle.edge
|           |   |           `-- undirectedTriangle.gml
|           |   |-- net
|           |   |   `-- test
|           |   |       `-- TestRMI.java
|           |   |-- netstream
|           |   |   `-- test
|           |   |       |-- ExampleNetStreamClientReceives.java
|           |   |       |-- ExampleNetStreamClientSends.java
|           |   |       |-- TestNetStreamDecoder.java
|           |   |       |-- TestNetStreamEncoder.java
|           |   |       `-- TestNetStreamUtils.java
|           |   |-- sync
|           |   |   `-- TestSync.java
|           |   |-- test
|           |   |   |-- TestAnnotatedSink.java
|           |   |   |-- TestAutoCreateInStreams.java
|           |   |   `-- TestSourceBase.java
|           |   `-- thread
|           |       `-- test
|           |           `-- TestThreadProxyPipe.java
|           |-- ui
|           |   |-- graphicGraph
|           |   |   |-- parser
|           |   |   |   `-- test
|           |   |   |       `-- TestStyleSheet.java
|           |   |   `-- test
|           |   |       |-- TestGraphSynchronisationProxyThread.java
|           |   |       `-- TestGraphicGraph.java
|           |   `-- test
|           |       `-- util
|           |           `-- Display.java
|           `-- util
|               `-- test
|                   |-- TestDisplay.java
|                   |-- TestEnvironment.java
|                   `-- data
|                       `-- TestFilteredIterators.dgs
|-- target
|   |-- archive-tmp
|   |-- generated-sources
|   |   `-- annotations
|   |-- generated-test-sources
|   |   `-- test-annotations
|   |-- gs-core-2.0.0-beta-jar-with-dependencies.jar
|   |-- gs-core-2.0.0-beta.jar
|   |-- jacoco.exec
|   |-- maven-archiver
|   |   `-- pom.properties
|   |-- maven-status
|   |   `-- maven-compiler-plugin
|   |       |-- compile
|   |       |   `-- default-compile
|   |       |       |-- createdFiles.lst
|   |       |       `-- inputFiles.lst
|   |       `-- testCompile
|   |           `-- default-testCompile
|   |               |-- createdFiles.lst
|   |               `-- inputFiles.lst
|   |-- site
|   |   `-- jacoco
|   |       |-- index.html
|   |       |-- jacoco-resources
|   |       |   |-- branchfc.gif
|   |       |   |-- branchnc.gif
|   |       |   |-- branchpc.gif
|   |       |   |-- bundle.gif
|   |       |   |-- class.gif
|   |       |   |-- down.gif
|   |       |   |-- greenbar.gif
|   |       |   |-- group.gif
|   |       |   |-- method.gif
|   |       |   |-- package.gif
|   |       |   |-- prettify.css
|   |       |   |-- prettify.js
|   |       |   |-- redbar.gif
|   |       |   |-- report.css
|   |       |   |-- report.gif
|   |       |   |-- session.gif
|   |       |   |-- sort.gif
|   |       |   |-- sort.js
|   |       |   |-- source.gif
|   |       |   `-- up.gif
|   |       |-- jacoco-sessions.html
|   |       |-- jacoco.csv
|   |       |-- jacoco.xml
|   |       |-- org.graphstream.graph
|   |       |   |-- BreadthFirstIterator.html
|   |       |   |-- BreadthFirstIterator.java.html
|   |       |   |-- DepthFirstIterator.html
|   |       |   |-- DepthFirstIterator.java.html
|   |       |   |-- EdgeRejectedException.html
|   |       |   |-- EdgeRejectedException.java.html
|   |       |   |-- Element.html
|   |       |   |-- Element.java.html
|   |       |   |-- ElementNotFoundException.html
|   |       |   |-- ElementNotFoundException.java.html
|   |       |   |-- Graph.html
|   |       |   |-- Graph.java.html
|   |       |   |-- GraphFactory.html
|   |       |   |-- GraphFactory.java.html
|   |       |   |-- IdAlreadyInUseException.html
|   |       |   |-- IdAlreadyInUseException.java.html
|   |       |   |-- Node.html
|   |       |   |-- Node.java.html
|   |       |   |-- Path.html
|   |       |   |-- Path.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.graph.implementations
|   |       |   |-- AbstractEdge.html
|   |       |   |-- AbstractEdge.java.html
|   |       |   |-- AbstractElement$AttributeChangeEvent.html
|   |       |   |-- AbstractElement.html
|   |       |   |-- AbstractElement.java.html
|   |       |   |-- AbstractGraph$GraphReplayController.html
|   |       |   |-- AbstractGraph.html
|   |       |   |-- AbstractGraph.java.html
|   |       |   |-- AbstractNode.html
|   |       |   |-- AbstractNode.java.html
|   |       |   |-- AdjacencyListGraph$1.html
|   |       |   |-- AdjacencyListGraph$2.html
|   |       |   |-- AdjacencyListGraph$EdgeIterator.html
|   |       |   |-- AdjacencyListGraph$NodeIterator.html
|   |       |   |-- AdjacencyListGraph.html
|   |       |   |-- AdjacencyListGraph.java.html
|   |       |   |-- AdjacencyListNode$EdgeIterator.html
|   |       |   |-- AdjacencyListNode.html
|   |       |   |-- AdjacencyListNode.java.html
|   |       |   |-- DefaultGraph.html
|   |       |   |-- DefaultGraph.java.html
|   |       |   |-- Graphs$SynchronizedEdge.html
|   |       |   |-- Graphs$SynchronizedElement.html
|   |       |   |-- Graphs$SynchronizedGraph.html
|   |       |   |-- Graphs$SynchronizedNode.html
|   |       |   |-- Graphs.html
|   |       |   |-- Graphs.java.html
|   |       |   |-- MultiGraph$1.html
|   |       |   |-- MultiGraph.html
|   |       |   |-- MultiGraph.java.html
|   |       |   |-- MultiNode.html
|   |       |   |-- MultiNode.java.html
|   |       |   |-- OneAttributeElement$AttributeChangeEvent.html
|   |       |   |-- OneAttributeElement.html
|   |       |   |-- OneAttributeElement.java.html
|   |       |   |-- SingleGraph$1.html
|   |       |   |-- SingleGraph.html
|   |       |   |-- SingleGraph.java.html
|   |       |   |-- SingleNode$TwoEdges.html
|   |       |   |-- SingleNode.html
|   |       |   |-- SingleNode.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream
|   |       |   |-- AnnotatedSink.html
|   |       |   |-- AnnotatedSink.java.html
|   |       |   |-- AttributePipe$FalsePredicate.html
|   |       |   |-- AttributePipe.html
|   |       |   |-- AttributePipe.java.html
|   |       |   |-- GraphParseException.html
|   |       |   |-- GraphParseException.java.html
|   |       |   |-- GraphReplay.html
|   |       |   |-- GraphReplay.java.html
|   |       |   |-- PipeAdapter.html
|   |       |   |-- PipeAdapter.java.html
|   |       |   |-- PipeBase.html
|   |       |   |-- PipeBase.java.html
|   |       |   |-- Replayable.html
|   |       |   |-- Replayable.java.html
|   |       |   |-- SinkAdapter.html
|   |       |   |-- SinkAdapter.java.html
|   |       |   |-- SourceAdapter.html
|   |       |   |-- SourceAdapter.java.html
|   |       |   |-- SourceBase$AddToListEvent.html
|   |       |   |-- SourceBase$AfterEdgeAddEvent.html
|   |       |   |-- SourceBase$AfterNodeAddEvent.html
|   |       |   |-- SourceBase$AttributeChangedEvent.html
|   |       |   |-- SourceBase$BeforeEdgeRemoveEvent.html
|   |       |   |-- SourceBase$BeforeGraphClearEvent.html
|   |       |   |-- SourceBase$BeforeNodeRemoveEvent.html
|   |       |   |-- SourceBase$ClearListEvent.html
|   |       |   |-- SourceBase$ElementType.html
|   |       |   |-- SourceBase$GraphEvent.html
|   |       |   |-- SourceBase$RemoveFromListEvent.html
|   |       |   |-- SourceBase$StepBeginsEvent.html
|   |       |   |-- SourceBase.html
|   |       |   |-- SourceBase.java.html
|   |       |   |-- Timeline$Connector.html
|   |       |   |-- Timeline$StepDiff.html
|   |       |   |-- Timeline$TimelineIterator.html
|   |       |   |-- Timeline$TimelineReplayController.html
|   |       |   |-- Timeline.html
|   |       |   |-- Timeline.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.binary
|   |       |   |-- ByteProxy$1.html
|   |       |   |-- ByteProxy$2.html
|   |       |   |-- ByteProxy$3.html
|   |       |   |-- ByteProxy$Mode.html
|   |       |   |-- ByteProxy.html
|   |       |   |-- ByteProxy.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file
|   |       |   |-- FileSinkBase.html
|   |       |   |-- FileSinkBase.java.html
|   |       |   |-- FileSinkBaseFiltered.html
|   |       |   |-- FileSinkBaseFiltered.java.html
|   |       |   |-- FileSinkDGS.html
|   |       |   |-- FileSinkDGS.java.html
|   |       |   |-- FileSinkDGSFiltered.html
|   |       |   |-- FileSinkDGSFiltered.java.html
|   |       |   |-- FileSinkDGSUtility.html
|   |       |   |-- FileSinkDGSUtility.java.html
|   |       |   |-- FileSinkDOT$What.html
|   |       |   |-- FileSinkDOT.html
|   |       |   |-- FileSinkDOT.java.html
|   |       |   |-- FileSinkDynamicGML.html
|   |       |   |-- FileSinkDynamicGML.java.html
|   |       |   |-- FileSinkFactory.html
|   |       |   |-- FileSinkFactory.java.html
|   |       |   |-- FileSinkGEXF$GEXFAttribute.html
|   |       |   |-- FileSinkGEXF$GEXFAttributeMap.html
|   |       |   |-- FileSinkGEXF$TimeFormat.html
|   |       |   |-- FileSinkGEXF.html
|   |       |   |-- FileSinkGEXF.java.html
|   |       |   |-- FileSinkGEXF2$Context.html
|   |       |   |-- FileSinkGEXF2.html
|   |       |   |-- FileSinkGEXF2.java.html
|   |       |   |-- FileSinkGML.html
|   |       |   |-- FileSinkGML.java.html
|   |       |   |-- FileSinkGraphML.html
|   |       |   |-- FileSinkGraphML.java.html
|   |       |   |-- FileSinkImages$InnerLayoutRunner.html
|   |       |   |-- FileSinkImages$LayoutPolicy.html
|   |       |   |-- FileSinkImages$Option.html
|   |       |   |-- FileSinkImages$OutputPolicy.html
|   |       |   |-- FileSinkImages$OutputRunner.html
|   |       |   |-- FileSinkImages$OutputType.html
|   |       |   |-- FileSinkImages$Quality.html
|   |       |   |-- FileSinkImages.html
|   |       |   |-- FileSinkImages.java.html
|   |       |   |-- FileSinkSVG$What.html
|   |       |   |-- FileSinkSVG.html
|   |       |   |-- FileSinkSVG.java.html
|   |       |   |-- FileSinkSVG2$SVGContext.html
|   |       |   |-- FileSinkSVG2$SVGStyle.html
|   |       |   |-- FileSinkSVG2$ViewBox.html
|   |       |   |-- FileSinkSVG2$XMLWriter.html
|   |       |   |-- FileSinkSVG2.html
|   |       |   |-- FileSinkSVG2.java.html
|   |       |   |-- FileSinkTikZ$PointsWrapper.html
|   |       |   |-- FileSinkTikZ.html
|   |       |   |-- FileSinkTikZ.java.html
|   |       |   |-- FileSourceBase$CurrentFile.html
|   |       |   |-- FileSourceBase.html
|   |       |   |-- FileSourceBase.java.html
|   |       |   |-- FileSourceDGS$1.html
|   |       |   |-- FileSourceDGS.html
|   |       |   |-- FileSourceDGS.java.html
|   |       |   |-- FileSourceDGS1And2$AttributeFormat.html
|   |       |   |-- FileSourceDGS1And2$AttributeType.html
|   |       |   |-- FileSourceDGS1And2.html
|   |       |   |-- FileSourceDGS1And2.java.html
|   |       |   |-- FileSourceDOT$1.html
|   |       |   |-- FileSourceDOT.html
|   |       |   |-- FileSourceDOT.java.html
|   |       |   |-- FileSourceEdge.html
|   |       |   |-- FileSourceEdge.java.html
|   |       |   |-- FileSourceFactory.html
|   |       |   |-- FileSourceFactory.java.html
|   |       |   |-- FileSourceGEXF$Attribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$ATTRIBUTEAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$ATTRIBUTESAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$ATTVALUEAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$AttributeType.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$Balise.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$COLORAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$ClassType.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$EDGEAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$EDGESAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$EDGESHAPEAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$EdgeShapeType.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$EdgeType.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$GEXFAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$GRAPHAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$IDType.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$METAAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$ModeType.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$NODEAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$NODESAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$NODESHAPEAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$NodeShapeType.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$PARENTAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$POSITIONAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$SIZEAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$SPELLAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$THICKNESSAttribute.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$TimeFormatType.html
|   |       |   |-- FileSourceGEXF$GEXFConstants$WeightType.html
|   |       |   |-- FileSourceGEXF$GEXFParser.html
|   |       |   |-- FileSourceGEXF.html
|   |       |   |-- FileSourceGEXF.java.html
|   |       |   |-- FileSourceGML$1.html
|   |       |   |-- FileSourceGML.html
|   |       |   |-- FileSourceGML.java.html
|   |       |   |-- FileSourceGPX$GPXConstants$BOUNDSAttribute.html
|   |       |   |-- FileSourceGPX$GPXConstants$Balise.html
|   |       |   |-- FileSourceGPX$GPXConstants$COPYRIGHTAttribute.html
|   |       |   |-- FileSourceGPX$GPXConstants$EMAILAttribute.html
|   |       |   |-- FileSourceGPX$GPXConstants$FixType.html
|   |       |   |-- FileSourceGPX$GPXConstants$GPXAttribute.html
|   |       |   |-- FileSourceGPX$GPXConstants$LINKAttribute.html
|   |       |   |-- FileSourceGPX$GPXConstants$PTAttribute.html
|   |       |   |-- FileSourceGPX$GPXConstants$WPTAttribute.html
|   |       |   |-- FileSourceGPX$GPXParser.html
|   |       |   |-- FileSourceGPX$WayPoint.html
|   |       |   |-- FileSourceGPX.html
|   |       |   |-- FileSourceGPX.java.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$Balise.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$Data.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$DataAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$EdgeAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$EndPoint.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$EndPointAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$EndPointType.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$GraphAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$HyperEdgeAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$Key.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$KeyAttrType.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$KeyAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$KeyDomain.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$Locator.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$LocatorAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$NodeAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$Port.html
|   |       |   |-- FileSourceGraphML$GraphMLConstants$PortAttribute.html
|   |       |   |-- FileSourceGraphML$GraphMLParser.html
|   |       |   |-- FileSourceGraphML.html
|   |       |   |-- FileSourceGraphML.java.html
|   |       |   |-- FileSourceLGL.html
|   |       |   |-- FileSourceLGL.java.html
|   |       |   |-- FileSourceNCol.html
|   |       |   |-- FileSourceNCol.java.html
|   |       |   |-- FileSourcePajek$1.html
|   |       |   |-- FileSourcePajek.html
|   |       |   |-- FileSourcePajek.java.html
|   |       |   |-- FileSourceParser.html
|   |       |   |-- FileSourceParser.java.html
|   |       |   |-- FileSourceTLP$1.html
|   |       |   |-- FileSourceTLP.html
|   |       |   |-- FileSourceTLP.java.html
|   |       |   |-- FileSourceXML$Parser.html
|   |       |   |-- FileSourceXML.html
|   |       |   |-- FileSourceXML.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file.dgs
|   |       |   |-- DGSParser$Token.html
|   |       |   |-- DGSParser.html
|   |       |   |-- DGSParser.java.html
|   |       |   |-- OldFileSourceDGS.html
|   |       |   |-- OldFileSourceDGS.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file.dot
|   |       |   |-- DOTParser$JJCalls.html
|   |       |   |-- DOTParser.html
|   |       |   |-- DOTParser.java.html
|   |       |   |-- DOTParserConstants.html
|   |       |   |-- DOTParserConstants.java.html
|   |       |   |-- DOTParserTokenManager.html
|   |       |   |-- DOTParserTokenManager.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file.gexf
|   |       |   |-- GEXF.html
|   |       |   |-- GEXF.java.html
|   |       |   |-- GEXFAttValue.html
|   |       |   |-- GEXFAttValue.java.html
|   |       |   |-- GEXFAttValues.html
|   |       |   |-- GEXFAttValues.java.html
|   |       |   |-- GEXFAttribute.html
|   |       |   |-- GEXFAttribute.java.html
|   |       |   |-- GEXFAttributes.html
|   |       |   |-- GEXFAttributes.java.html
|   |       |   |-- GEXFEdge.html
|   |       |   |-- GEXFEdge.java.html
|   |       |   |-- GEXFEdges.html
|   |       |   |-- GEXFEdges.java.html
|   |       |   |-- GEXFElement$AttrType.html
|   |       |   |-- GEXFElement$ClassType.html
|   |       |   |-- GEXFElement$DefaultEdgeType.html
|   |       |   |-- GEXFElement$Extension.html
|   |       |   |-- GEXFElement$IDType.html
|   |       |   |-- GEXFElement$Mode.html
|   |       |   |-- GEXFElement$TimeFormat.html
|   |       |   |-- GEXFElement.java.html
|   |       |   |-- GEXFGraph.html
|   |       |   |-- GEXFGraph.java.html
|   |       |   |-- GEXFMeta.html
|   |       |   |-- GEXFMeta.java.html
|   |       |   |-- GEXFNode.html
|   |       |   |-- GEXFNode.java.html
|   |       |   |-- GEXFNodes.html
|   |       |   |-- GEXFNodes.java.html
|   |       |   |-- GEXFSpell.html
|   |       |   |-- GEXFSpell.java.html
|   |       |   |-- GEXFSpells.html
|   |       |   |-- GEXFSpells.java.html
|   |       |   |-- SmartXMLWriter.html
|   |       |   |-- SmartXMLWriter.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file.gml
|   |       |   |-- GMLContext.html
|   |       |   |-- GMLContext.java.html
|   |       |   |-- GMLParser.html
|   |       |   |-- GMLParser.java.html
|   |       |   |-- GMLParserConstants.html
|   |       |   |-- GMLParserConstants.java.html
|   |       |   |-- GMLParserTokenManager.html
|   |       |   |-- GMLParserTokenManager.java.html
|   |       |   |-- Graphics.html
|   |       |   |-- KeyValues.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file.images
|   |       |   |-- CustomResolution.html
|   |       |   |-- CustomResolution.java.html
|   |       |   |-- Resolutions.html
|   |       |   |-- Resolutions.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file.images.filters
|   |       |   |-- AddLogoFilter.html
|   |       |   |-- AddLogoFilter.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file.pajek
|   |       |   |-- EdgeGraphics.html
|   |       |   |-- EdgeMatrix.html
|   |       |   |-- Graphics.html
|   |       |   |-- NodeGraphics.html
|   |       |   |-- PajekContext.html
|   |       |   |-- PajekContext.java.html
|   |       |   |-- PajekParser$JJCalls.html
|   |       |   |-- PajekParser.html
|   |       |   |-- PajekParser.java.html
|   |       |   |-- PajekParserConstants.html
|   |       |   |-- PajekParserConstants.java.html
|   |       |   |-- PajekParserTokenManager.html
|   |       |   |-- PajekParserTokenManager.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.file.tlp
|   |       |   |-- TLPParser$Cluster.html
|   |       |   |-- TLPParser$JJCalls.html
|   |       |   |-- TLPParser$PropertyType.html
|   |       |   |-- TLPParser.html
|   |       |   |-- TLPParser.java.html
|   |       |   |-- TLPParserConstants.html
|   |       |   |-- TLPParserConstants.java.html
|   |       |   |-- TLPParserTokenManager.html
|   |       |   |-- TLPParserTokenManager.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.netstream
|   |       |   |-- NetStreamConstants.html
|   |       |   |-- NetStreamConstants.java.html
|   |       |   |-- NetStreamDecoder.html
|   |       |   |-- NetStreamDecoder.java.html
|   |       |   |-- NetStreamEncoder.html
|   |       |   |-- NetStreamEncoder.java.html
|   |       |   |-- NetStreamUtils$1.html
|   |       |   |-- NetStreamUtils.html
|   |       |   |-- NetStreamUtils.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.rmi
|   |       |   |-- RMISink.html
|   |       |   |-- RMISink.java.html
|   |       |   |-- RMISource.html
|   |       |   |-- RMISource.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.sync
|   |       |   |-- SinkTime.html
|   |       |   |-- SinkTime.java.html
|   |       |   |-- SourceTime.html
|   |       |   |-- SourceTime.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.stream.thread
|   |       |   |-- ThreadProxyPipe$GraphEvents.html
|   |       |   |-- ThreadProxyPipe.html
|   |       |   |-- ThreadProxyPipe.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.geom
|   |       |   |-- Point2.html
|   |       |   |-- Point2.java.html
|   |       |   |-- Point3.html
|   |       |   |-- Point3.java.html
|   |       |   |-- Vector2.html
|   |       |   |-- Vector2.java.html
|   |       |   |-- Vector3.html
|   |       |   |-- Vector3.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.graphicGraph
|   |       |   |-- GraphPosLengthUtils.html
|   |       |   |-- GraphPosLengthUtils.java.html
|   |       |   |-- GraphicEdge$EdgeGroup.html
|   |       |   |-- GraphicEdge.html
|   |       |   |-- GraphicEdge.java.html
|   |       |   |-- GraphicElement.html
|   |       |   |-- GraphicElement.java.html
|   |       |   |-- GraphicGraph.html
|   |       |   |-- GraphicGraph.java.html
|   |       |   |-- GraphicNode.html
|   |       |   |-- GraphicNode.java.html
|   |       |   |-- GraphicSprite.html
|   |       |   |-- GraphicSprite.java.html
|   |       |   |-- StyleGroup$BulkElements.html
|   |       |   |-- StyleGroup$BulkIterator.html
|   |       |   |-- StyleGroup$ElementEvents.html
|   |       |   |-- StyleGroup.html
|   |       |   |-- StyleGroup.java.html
|   |       |   |-- StyleGroupSet$EdgeSet.html
|   |       |   |-- StyleGroupSet$ElementIterator.html
|   |       |   |-- StyleGroupSet$EventSet.html
|   |       |   |-- StyleGroupSet$GraphSet.html
|   |       |   |-- StyleGroupSet$NodeSet.html
|   |       |   |-- StyleGroupSet$ShadowSet.html
|   |       |   |-- StyleGroupSet$SpriteSet.html
|   |       |   |-- StyleGroupSet$ZIndex$ZIndexIterator.html
|   |       |   |-- StyleGroupSet$ZIndex.html
|   |       |   |-- StyleGroupSet.html
|   |       |   |-- StyleGroupSet.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.graphicGraph.stylesheet
|   |       |   |-- Color.html
|   |       |   |-- Color.java.html
|   |       |   |-- Colors.html
|   |       |   |-- Colors.java.html
|   |       |   |-- Rule.html
|   |       |   |-- Rule.java.html
|   |       |   |-- Selector$Type.html
|   |       |   |-- Selector.html
|   |       |   |-- Selector.java.html
|   |       |   |-- Style.html
|   |       |   |-- Style.java.html
|   |       |   |-- StyleConstants$ArrowShape.html
|   |       |   |-- StyleConstants$FillMode.html
|   |       |   |-- StyleConstants$IconMode.html
|   |       |   |-- StyleConstants$JComponents.html
|   |       |   |-- StyleConstants$ShadowMode.html
|   |       |   |-- StyleConstants$Shape.html
|   |       |   |-- StyleConstants$ShapeKind.html
|   |       |   |-- StyleConstants$SizeMode.html
|   |       |   |-- StyleConstants$SpriteOrientation.html
|   |       |   |-- StyleConstants$StrokeMode.html
|   |       |   |-- StyleConstants$TextAlignment.html
|   |       |   |-- StyleConstants$TextBackgroundMode.html
|   |       |   |-- StyleConstants$TextMode.html
|   |       |   |-- StyleConstants$TextStyle.html
|   |       |   |-- StyleConstants$TextVisibilityMode.html
|   |       |   |-- StyleConstants$Units.html
|   |       |   |-- StyleConstants$VisibilityMode.html
|   |       |   |-- StyleConstants.html
|   |       |   |-- StyleConstants.java.html
|   |       |   |-- StyleSheet$NameSpace.html
|   |       |   |-- StyleSheet.html
|   |       |   |-- StyleSheet.java.html
|   |       |   |-- Value.html
|   |       |   |-- Value.java.html
|   |       |   |-- Values.html
|   |       |   |-- Values.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.graphicGraph.stylesheet.parser
|   |       |   |-- StyleSheetParser$Number.html
|   |       |   |-- StyleSheetParser.html
|   |       |   |-- StyleSheetParser.java.html
|   |       |   |-- StyleSheetParserConstants.html
|   |       |   |-- StyleSheetParserConstants.java.html
|   |       |   |-- StyleSheetParserTokenManager.html
|   |       |   |-- StyleSheetParserTokenManager.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.layout
|   |       |   |-- LayoutRunner.html
|   |       |   |-- LayoutRunner.java.html
|   |       |   |-- Layouts.html
|   |       |   |-- Layouts.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.layout.springbox
|   |       |   |-- BarnesHutLayout.html
|   |       |   |-- BarnesHutLayout.java.html
|   |       |   |-- EdgeSpring.html
|   |       |   |-- EdgeSpring.java.html
|   |       |   |-- Energies.html
|   |       |   |-- Energies.java.html
|   |       |   |-- GraphCellData.html
|   |       |   |-- GraphCellData.java.html
|   |       |   |-- NodeParticle.html
|   |       |   |-- NodeParticle.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.layout.springbox.implementations
|   |       |   |-- LinLog.html
|   |       |   |-- LinLog.java.html
|   |       |   |-- LinLogNodeParticle.html
|   |       |   |-- LinLogNodeParticle.java.html
|   |       |   |-- SpringBox.html
|   |       |   |-- SpringBox.java.html
|   |       |   |-- SpringBoxNodeParticle.html
|   |       |   |-- SpringBoxNodeParticle.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.spriteManager
|   |       |   |-- InvalidSpriteIDException.html
|   |       |   |-- InvalidSpriteIDException.java.html
|   |       |   |-- Sprite.html
|   |       |   |-- Sprite.java.html
|   |       |   |-- SpriteFactory.html
|   |       |   |-- SpriteFactory.java.html
|   |       |   |-- SpriteManager.html
|   |       |   |-- SpriteManager.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.view
|   |       |   |-- GraphRendererBase.html
|   |       |   |-- GraphRendererBase.java.html
|   |       |   |-- Selection.html
|   |       |   |-- Selection.java.html
|   |       |   |-- Viewer$CloseFramePolicy.html
|   |       |   |-- Viewer$ThreadingModel.html
|   |       |   |-- Viewer.html
|   |       |   |-- Viewer.java.html
|   |       |   |-- ViewerPipe.html
|   |       |   |-- ViewerPipe.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.view.camera
|   |       |   |-- DefaultCamera2D.html
|   |       |   |-- DefaultCamera2D.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.ui.view.util
|   |       |   |-- FpsCounter.html
|   |       |   |-- FpsCounter.java.html
|   |       |   |-- GraphMetrics.html
|   |       |   |-- GraphMetrics.java.html
|   |       |   |-- InteractiveElement.html
|   |       |   |-- InteractiveElement.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.util
|   |       |   |-- Display.html
|   |       |   |-- Display.java.html
|   |       |   |-- Environment.html
|   |       |   |-- Environment.java.html
|   |       |   |-- GraphDiff$AttributeAdded.html
|   |       |   |-- GraphDiff$AttributeChanged.html
|   |       |   |-- GraphDiff$AttributeRemoved.html
|   |       |   |-- GraphDiff$Bridge.html
|   |       |   |-- GraphDiff$EdgeAdded.html
|   |       |   |-- GraphDiff$EdgeRemoved.html
|   |       |   |-- GraphDiff$ElementEvent.html
|   |       |   |-- GraphDiff$ElementType.html
|   |       |   |-- GraphDiff$Event.html
|   |       |   |-- GraphDiff$GraphCleared.html
|   |       |   |-- GraphDiff$NodeAdded.html
|   |       |   |-- GraphDiff$NodeRemoved.html
|   |       |   |-- GraphDiff$StepBegins.html
|   |       |   |-- GraphDiff.html
|   |       |   |-- GraphDiff.java.html
|   |       |   |-- GraphListeners.html
|   |       |   |-- GraphListeners.java.html
|   |       |   |-- MissingDisplayException.html
|   |       |   |-- MissingDisplayException.java.html
|   |       |   |-- StepCounter.html
|   |       |   |-- StepCounter.java.html
|   |       |   |-- VerboseSink$EventType.html
|   |       |   |-- VerboseSink.html
|   |       |   |-- VerboseSink.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.util.cumulative
|   |       |   |-- CumulativeAttributes.html
|   |       |   |-- CumulativeAttributes.java.html
|   |       |   |-- CumulativeSpells$Spell.html
|   |       |   |-- CumulativeSpells.html
|   |       |   |-- CumulativeSpells.java.html
|   |       |   |-- GraphSpells$EdgeData.html
|   |       |   |-- GraphSpells.html
|   |       |   |-- GraphSpells.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.util.parser
|   |       |   |-- ParseException.html
|   |       |   |-- ParseException.java.html
|   |       |   |-- SimpleCharStream.html
|   |       |   |-- SimpleCharStream.java.html
|   |       |   |-- Token.html
|   |       |   |-- Token.java.html
|   |       |   |-- TokenMgrError.html
|   |       |   |-- TokenMgrError.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       |-- org.graphstream.util.set
|   |       |   |-- FixedArrayList$FixedArrayIterator.html
|   |       |   |-- FixedArrayList.html
|   |       |   |-- FixedArrayList.java.html
|   |       |   |-- index.html
|   |       |   `-- index.source.html
|   |       `-- org.graphstream.util.time
|   |           |-- ISODateComponent$AMPMComponent.html
|   |           |-- ISODateComponent$AliasComponent.html
|   |           |-- ISODateComponent$EpochComponent.html
|   |           |-- ISODateComponent$FieldComponent.html
|   |           |-- ISODateComponent$LocaleDependentComponent.html
|   |           |-- ISODateComponent$NotImplementedComponent.html
|   |           |-- ISODateComponent$TextComponent.html
|   |           |-- ISODateComponent$UTCOffsetComponent.html
|   |           |-- ISODateComponent.html
|   |           |-- ISODateComponent.java.html
|   |           |-- ISODateIO.html
|   |           |-- ISODateIO.java.html
|   |           |-- index.html
|   |           `-- index.source.html
|   |-- surefire-reports
|   |   |-- 2020-05-17T21-18-22_845-jvmRun1.dump
|   |   |-- 2020-05-17T21-18-22_845.dumpstream
|   |   |-- TEST-org.graphstream.graph.test.TestAbstractElement.xml
|   |   |-- TEST-org.graphstream.graph.test.TestElement.xml
|   |   |-- TEST-org.graphstream.graph.test.TestGraph.xml
|   |   |-- TEST-org.graphstream.graph.test.TestGraphSynchronisation.xml
|   |   |-- TEST-org.graphstream.stream.file.dgs.test.TestDGSParser.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSinkDGS.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSinkDOT.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSinkGraphML.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSourceDGS.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSourceDOT.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSourceEdge.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSourceGEXF.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSourceGML.xml
|   |   |-- TEST-org.graphstream.stream.file.test.TestFileSourceGraphML.xml
|   |   |-- TEST-org.graphstream.stream.net.test.TestRMI.xml
|   |   |-- TEST-org.graphstream.stream.netstream.test.TestNetStreamDecoder.xml
|   |   |-- TEST-org.graphstream.stream.netstream.test.TestNetStreamEncoder.xml
|   |   |-- TEST-org.graphstream.stream.netstream.test.TestNetStreamUtils.xml
|   |   |-- TEST-org.graphstream.stream.sync.TestSync.xml
|   |   |-- TEST-org.graphstream.stream.test.TestAnnotatedSink.xml
|   |   |-- TEST-org.graphstream.stream.test.TestAutoCreateInStreams.xml
|   |   |-- TEST-org.graphstream.stream.test.TestSourceBase.xml
|   |   |-- TEST-org.graphstream.stream.thread.test.TestThreadProxyPipe.xml
|   |   |-- TEST-org.graphstream.ui.graphicGraph.parser.test.TestStyleSheet.xml
|   |   |-- TEST-org.graphstream.ui.graphicGraph.test.TestGraphSynchronisationProxyThread.xml
|   |   |-- TEST-org.graphstream.ui.graphicGraph.test.TestGraphicGraph.xml
|   |   |-- TEST-org.graphstream.util.test.TestDisplay.xml
|   |   |-- org.graphstream.graph.test.TestAbstractElement.txt
|   |   |-- org.graphstream.graph.test.TestElement.txt
|   |   |-- org.graphstream.graph.test.TestGraph.txt
|   |   |-- org.graphstream.graph.test.TestGraphSynchronisation.txt
|   |   |-- org.graphstream.stream.file.dgs.test.TestDGSParser.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSinkDGS.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSinkDOT.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSinkGraphML.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSourceDGS.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSourceDOT.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSourceEdge.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSourceGEXF.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSourceGML.txt
|   |   |-- org.graphstream.stream.file.test.TestFileSourceGraphML.txt
|   |   |-- org.graphstream.stream.net.test.TestRMI.txt
|   |   |-- org.graphstream.stream.netstream.test.TestNetStreamDecoder.txt
|   |   |-- org.graphstream.stream.netstream.test.TestNetStreamEncoder.txt
|   |   |-- org.graphstream.stream.netstream.test.TestNetStreamUtils.txt
|   |   |-- org.graphstream.stream.sync.TestSync.txt
|   |   |-- org.graphstream.stream.test.TestAnnotatedSink.txt
|   |   |-- org.graphstream.stream.test.TestAutoCreateInStreams.txt
|   |   |-- org.graphstream.stream.test.TestSourceBase.txt
|   |   |-- org.graphstream.stream.thread.test.TestThreadProxyPipe.txt
|   |   |-- org.graphstream.ui.graphicGraph.parser.test.TestStyleSheet.txt
|   |   |-- org.graphstream.ui.graphicGraph.test.TestGraphSynchronisationProxyThread.txt
|   |   |-- org.graphstream.ui.graphicGraph.test.TestGraphicGraph.txt
|   |   `-- org.graphstream.util.test.TestDisplay.txt
|   `-- test-classes
|       `-- org
|           `-- graphstream
|               |-- graph
|               |   `-- test
|               |       |-- BenchPerformance$Measures.class
|               |       |-- BenchPerformance.class
|               |       |-- TestAbstractElement$LocalAbstractElement.class
|               |       |-- TestAbstractElement.class
|               |       |-- TestElement.class
|               |       |-- TestGraph.class
|               |       `-- TestGraphSynchronisation.class
|               |-- stream
|               |   |-- binary
|               |   |   `-- test
|               |   |       |-- ExampleByteProxy$1.class
|               |   |       |-- ExampleByteProxy$InternalByteDecoder.class
|               |   |       |-- ExampleByteProxy$InternalByteEncoder.class
|               |   |       `-- ExampleByteProxy.class
|               |   |-- file
|               |   |   |-- dgs
|               |   |   |   `-- test
|               |   |   |       |-- TestDGSParser$Attribute.class
|               |   |   |       |-- TestDGSParser$TestAttributeRemoved.class
|               |   |   |       |-- TestDGSParser.class
|               |   |   |       `-- data
|               |   |   |           |-- attributes.dgs
|               |   |   |           |-- attributes_array.dgs
|               |   |   |           |-- bad1.dgs
|               |   |   |           |-- bad2.dgs
|               |   |   |           |-- elements.dgs
|               |   |   |           `-- removeAttribute.dgs
|               |   |   |-- gml
|               |   |   |   `-- test
|               |   |   |       |-- TestSinkGML.class
|               |   |   |       `-- TestSourceGML.class
|               |   |   |-- pajek
|               |   |   |   `-- test
|               |   |   |       |-- TestPajekParser$TestEntry.class
|               |   |   |       `-- TestPajekParser.class
|               |   |   `-- test
|               |   |       |-- TestFileSinkBase.class
|               |   |       |-- TestFileSinkDGS.class
|               |   |       |-- TestFileSinkDOT.class
|               |   |       |-- TestFileSinkGraphML.class
|               |   |       |-- TestFileSourceBase.class
|               |   |       |-- TestFileSourceDGS.class
|               |   |       |-- TestFileSourceDOT.class
|               |   |       |-- TestFileSourceEdge.class
|               |   |       |-- TestFileSourceGEXF.class
|               |   |       |-- TestFileSourceGML.class
|               |   |       |-- TestFileSourceGraphML.class
|               |   |       `-- data
|               |   |           |-- basic.gexf
|               |   |           |-- data.gexf
|               |   |           |-- example-extraattributes.graphml
|               |   |           |-- example.graphml
|               |   |           |-- undirectedTriangle.dgs
|               |   |           |-- undirectedTriangle.dot
|               |   |           |-- undirectedTriangle.edge
|               |   |           `-- undirectedTriangle.gml
|               |   |-- net
|               |   |   `-- test
|               |   |       `-- TestRMI.class
|               |   |-- netstream
|               |   |   `-- test
|               |   |       |-- ExampleNetStreamClientReceives.class
|               |   |       |-- ExampleNetStreamClientSends.class
|               |   |       |-- TestNetStreamDecoder$1.class
|               |   |       |-- TestNetStreamDecoder$10.class
|               |   |       |-- TestNetStreamDecoder$2.class
|               |   |       |-- TestNetStreamDecoder$3.class
|               |   |       |-- TestNetStreamDecoder$4.class
|               |   |       |-- TestNetStreamDecoder$5.class
|               |   |       |-- TestNetStreamDecoder$6.class
|               |   |       |-- TestNetStreamDecoder$7.class
|               |   |       |-- TestNetStreamDecoder$8.class
|               |   |       |-- TestNetStreamDecoder$9.class
|               |   |       |-- TestNetStreamDecoder$FailSink.class
|               |   |       |-- TestNetStreamDecoder.class
|               |   |       |-- TestNetStreamEncoder$1.class
|               |   |       |-- TestNetStreamEncoder$2.class
|               |   |       |-- TestNetStreamEncoder$3.class
|               |   |       |-- TestNetStreamEncoder$4.class
|               |   |       |-- TestNetStreamEncoder$5.class
|               |   |       |-- TestNetStreamEncoder.class
|               |   |       `-- TestNetStreamUtils.class
|               |   |-- sync
|               |   |   |-- TestSync$TestSinkTime.class
|               |   |   `-- TestSync.class
|               |   |-- test
|               |   |   |-- TestAnnotatedSink$TestObject.class
|               |   |   |-- TestAnnotatedSink.class
|               |   |   |-- TestAutoCreateInStreams$1.class
|               |   |   |-- TestAutoCreateInStreams$2.class
|               |   |   |-- TestAutoCreateInStreams.class
|               |   |   |-- TestSourceBase$1.class
|               |   |   |-- TestSourceBase$Event.class
|               |   |   |-- TestSourceBase$EventStack.class
|               |   |   |-- TestSourceBase$EventType.class
|               |   |   |-- TestSourceBase$TestSource.class
|               |   |   `-- TestSourceBase.class
|               |   `-- thread
|               |       `-- test
|               |           |-- TestThreadProxyPipe$1.class
|               |           |-- TestThreadProxyPipe$Actor.class
|               |           |-- TestThreadProxyPipe$AnotherThread.class
|               |           `-- TestThreadProxyPipe.class
|               |-- ui
|               |   |-- graphicGraph
|               |   |   |-- parser
|               |   |   |   `-- test
|               |   |   |       `-- TestStyleSheet.class
|               |   |   `-- test
|               |   |       |-- TestGraphSynchronisationProxyThread$InTheSwingThread.class
|               |   |       |-- TestGraphSynchronisationProxyThread.class
|               |   |       `-- TestGraphicGraph.class
|               |   `-- test
|               |       `-- util
|               |           `-- Display.class
|               `-- util
|                   `-- test
|                       |-- TestDisplay.class
|                       |-- TestEnvironment$TestContainer.class
|                       |-- TestEnvironment.class
|                       `-- data
|                           `-- TestFilteredIterators.dgs
|-- target.zip
`-- tree.md

199 directories, 1702 files
